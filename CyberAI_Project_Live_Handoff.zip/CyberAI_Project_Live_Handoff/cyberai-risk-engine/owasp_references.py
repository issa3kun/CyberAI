"""ASVS requirements related to CyberAI's surface observations."""

ASVS_VERSION = "5.0.0"
ASVS_URL = (
    "https://raw.githubusercontent.com/OWASP/ASVS/v5.0.0/5.0/"
    "OWASP_Application_Security_Verification_Standard_5.0.0_en.pdf"
)

FINDING_CONTROLS = {
    "https_not_used": (
        "12.2.1", "TLS for external HTTP services",
        "The submitted scheme describes this URL. Review the recorded response and redirect to determine where the application used TLS.",
    ),
    "https_redirects_to_http": (
        "12.2.1", "TLS for external HTTP services",
        "The observed redirect names an HTTP target. The finding alone leaves the target response unknown.",
    ),
    "tls_verification_failed": (
        "12.2.2", "Publicly trusted TLS certificates",
        "A failed TLS check can have several causes. Verify whether the certificate caused the failure.",
    ),
    "missing_or_weak_hsts": (
        "3.4.1", "HTTP Strict Transport Security",
        "The scanner checks for a positive max-age. Full verification also considers the required duration and subdomain coverage.",
    ),
    "missing_csp": (
        "3.4.3", "Content Security Policy",
        "The scanner reports CSP header presence. Full verification requires reviewing the policy directives and coverage.",
    ),
    "weak_x_content_type_options": (
        "3.4.4", "Content type sniffing protection",
        "The finding applies to this response. The requirement covers all applicable responses.",
    ),
    "missing_frame_protection": (
        "3.4.6", "Restrictions on which pages can embed the response",
        "The scanner also recognizes X-Frame-Options. ASVS calls for a CSP frame-ancestors directive, so this check cannot verify the whole requirement.",
    ),
    "cookie_missing_secure": (
        "3.3.1", "Secure cookie transport",
        "The scanner reports the attribute for observed cookies. The requirement also addresses cookie name prefixes.",
    ),
    "cookie_missing_httponly": (
        "3.3.4", "Protection from client-side script access",
        "Applicability depends on whether client-side scripts are supposed to access the cookie.",
    ),
    "cookie_missing_samesite": (
        "3.3.2", "SameSite policy suited to the cookie",
        "The finding records a missing attribute. The intended cookie behavior and application impact need separate evidence.",
    ),
    "cookie_invalid_samesite": (
        "3.3.2", "SameSite policy suited to the cookie",
        "The scanner reports the attribute value it could parse. Verify browser behavior and the purpose of the cookie.",
    ),
    "cookie_samesite_none_without_secure": (
        "3.3.1", "Secure cookie transport",
        "The scanner records a cookie using SameSite=None without Secure. The cookie's purpose and impact need separate evidence.",
    ),
}


def control_reference(finding_id):
    """Return a source link and the limits of the finding-to-control mapping."""
    control = FINDING_CONTROLS.get(finding_id)
    if control is None:
        return None
    requirement, title, coverage = control
    return {
        "framework": "OWASP ASVS",
        "version": ASVS_VERSION,
        "requirement": requirement,
        "title": title,
        "coverage": coverage,
        "url": ASVS_URL,
    }
