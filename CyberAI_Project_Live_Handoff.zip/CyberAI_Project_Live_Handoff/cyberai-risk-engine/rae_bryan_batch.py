"""Export offline URLhaus assessments for Bryan in CSA and OWASP JSONL."""

import argparse
from collections import Counter
from contextlib import ExitStack
import csv
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import BadZipFile

from rae_batch import BACKEND_DIR, open_export, sha256_file, urlhaus_rows, write_record
from scanner.url_checks import inspect_url_offline, load_csv_threats
from stage2_engine import ENGINE_VERSION, PERSPECTIVES, assess_scan, build_webhook_payload


FRAMEWORKS = ("csa", "owasp")


def run_batch(export_path, threat_path, output_dir):
    output_dir = output_dir.resolve()
    if output_dir.exists():
        raise FileExistsError(f"Output folder already exists: {output_dir}")

    threats = load_csv_threats(str(threat_path.resolve()), strict=True)
    if not threats:
        raise ValueError("The scanner threat CSV contains no usable threat URLs.")

    input_statuses = Counter()
    lookups = Counter()
    score_counts = {
        framework: dict.fromkeys(PERSPECTIVES, 0) for framework in FRAMEWORKS
    }
    scan_statuses = {framework: Counter() for framework in FRAMEWORKS}
    rejected = 0
    seen_urls = set()
    seen_ids = set()

    output_dir.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=output_dir.parent) as staging:
        folder = Path(staging) / "results"
        folder.mkdir()
        with ExitStack() as files:
            source = files.enter_context(open_export(export_path))
            results = {
                framework: files.enter_context(
                    (folder / f"{framework}.jsonl").open("w", encoding="utf-8", newline="\n")
                )
                for framework in FRAMEWORKS
            }
            rejects = files.enter_context(
                (folder / "rejected_rows.jsonl").open("w", encoding="utf-8", newline="\n")
            )
            export_updated, rows = urlhaus_rows(source)
            for row_number, row in enumerate(rows, 1):
                status = (row.get("url_status") or "").strip().lower()
                input_statuses[status or "missing"] += 1
                if status != "online":
                    continue

                record_id = row.get("id") or ""
                try:
                    if None in row or not record_id.isascii() or not record_id.isdecimal() or not row.get("threat"):
                        raise ValueError("Invalid ID, missing threat label, or extra columns.")
                    scanner_result = inspect_url_offline(row.get("url"), threats=threats)
                    url = scanner_result["url"]
                    if url in seen_urls or record_id in seen_ids:
                        raise ValueError("Duplicate URL or record ID.")
                    assessments = {
                        framework: assess_scan(scanner_result, framework=framework)
                        for framework in FRAMEWORKS
                    }
                except ValueError as exc:
                    rejected += 1
                    write_record(rejects, {"data_row": row_number, "reason": str(exc)})
                    continue

                for framework, assessment in assessments.items():
                    envelope = build_webhook_payload(
                        assessment, input_origin="user_supplied_scan", scan_id=f"urlhaus-{record_id}"
                    )
                    write_record(results[framework], envelope)
                    scan_statuses[framework][assessment["scan"]["status"]] += 1
                    for reader, data in assessment["perspectives"].items():
                        score_counts[framework][reader] += data["overall_risk"]["risk_score"] is not None

                matched = any(finding["id"] == "threat_list_match" for finding in scanner_result["findings"])
                lookups["match" if matched else "no_match"] += 1
                seen_urls.add(url)
                seen_ids.add(record_id)
                if len(seen_ids) % 10000 == 0:
                    print(f"Assessed {len(seen_ids):,} URLs in both frameworks.", flush=True)

        if rejected == 0:
            (folder / "rejected_rows.jsonl").unlink()

        summary = {
            "collection_method": "offline_reputation_replay",
            "scope": "URLhaus records marked online at export time. No DNS or HTTP requests are made.",
            "rae_engine_version": ENGINE_VERSION,
            "input_export": {
                "file": export_path.name,
                "updated": export_updated,
                "sha256": sha256_file(export_path),
            },
            "scanner_threat_list": {
                "file": threat_path.name,
                "sha256": sha256_file(threat_path),
                "indexed_urls": len(threats),
            },
            "input_rows": input_statuses.total(),
            "input_status_counts": dict(input_statuses),
            "rows_skipped_by_status": input_statuses.total() - input_statuses["online"],
            "rows_rejected": rejected,
            "urls_assessed": len(seen_ids),
            "scanner_lookup_counts": dict(lookups),
            "pairing": "The same scan_id and assessment.scan.url identify each URL across the JSONL files.",
            "frameworks": {
                framework: {
                    "file": f"{framework}.jsonl",
                    "records": len(seen_ids),
                    "rae_scan_status_counts": dict(scan_statuses[framework]),
                    "overall_scores_assigned": score_counts[framework],
                }
                for framework in FRAMEWORKS
            },
        }
        (folder / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        if output_dir.exists():
            raise FileExistsError(f"Output folder already exists: {output_dir}")
        folder.rename(output_dir)

    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("urlhaus_export", type=Path, help="Original URLhaus ZIP, CSV, or TXT export")
    parser.add_argument("--threat-list", type=Path, default=BACKEND_DIR / "clean_urls.csv",
                        help="Override the scanner's bundled reputation CSV")
    parser.add_argument("--output", type=Path, required=True, help="New output directory")
    args = parser.parse_args()
    try:
        summary = run_batch(args.urlhaus_export, args.threat_list, args.output)
    except (BadZipFile, csv.Error, OSError, ValueError) as exc:
        parser.exit(2, f"Batch failed: {exc}\n")

    print(f"Finished {summary['urls_assessed']:,} URLs per framework. "
          f"Rejected rows: {summary['rows_rejected']:,}.")
    print(f"CSA JSONL, OWASP JSONL and summary saved to {args.output}")


if __name__ == "__main__":
    main()
