# CyberAI Windows demo and testing

Open `cyberai-risk-engine` in VS Code. Open PowerShell terminals in that folder. Copy the numbered blocks below into the corresponding terminals. **Terminal 3 has one block for both testing and presenting.**

| What you are doing | Terminals | What to choose in Terminal 3 |
| --- | --- | --- |
| Repeatable test | **1 and 3** | Press Enter for **test**. Paste a saved raw scanner JSON path, or press Enter for the latest saved capture or `scan.json`. |
| Test with a fresh scan | **1, 2 and 3** | Press Enter for **test**, type `live`, then enter the authorised HTTP or HTTPS URL. |
| Presentation demo | **1, 2 and 3** | Type `demo`. Press Enter for a fresh scan of your prechecked, authorised URL. Paste a saved raw scanner JSON path to replay your rehearsal capture. |

Start your existing n8n instance in Docker Desktop if needed. From the folder containing its Compose file, run `docker compose up -d`. For the synthetic demo, put `rae_scoring_demo.py` beside `stage2_engine.py`.

## Terminal 1 — Start the RAE

This creates the Python environment and installs dependencies if `.venv` is missing, loads your saved RAE token or asks for it, and starts the RAE on port `5001`. Leave this terminal running. If the RAE is already running, use Terminal 3 to check its version.

```powershell
& {
    $ErrorActionPreference = 'Stop'
    $py = '.\.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $py -PathType Leaf)) {
        python -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
        & $py -m pip install -r requirements.txt
        if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
    }

    if (-not $env:CYBERAI_RAE_API_TOKEN) {
        $env:CYBERAI_RAE_API_TOKEN = [Environment]::GetEnvironmentVariable('CYBERAI_RAE_API_TOKEN', 'User')
    }
    if (-not $env:CYBERAI_RAE_API_TOKEN) {
        $env:CYBERAI_RAE_API_TOKEN = [System.Net.NetworkCredential]::new('', (Read-Host 'Paste the RAE token' -AsSecureString)).Password
    }
    & $py .\rae_api.py --host 0.0.0.0 --port 5001
}
```

## Terminal 2 — Start the scanner for a fresh scan

Start Ziyad’s scanner on port `5000`. This PowerShell session gives the scanner responsibility for collecting observations. Terminal 3 handles forwarding the saved output to n8n once per scoring method. Leave this terminal running.

```powershell
$env:CYBERAI_N8N_SCAN_WEBHOOK_URL = $null
.\.venv\Scripts\python.exe .\cyberai-api-backend\app.py
```

If the scanner is already running with automatic forwarding configured, restart it with this block for the walkthrough.

## Terminal 3 — Universal test and demo block

Copy the whole block. Enter a response at each PowerShell prompt. Use **Copy as path** in File Explorer when choosing a JSON file. The file should be raw scanner output, such as `ziyad_scan.json` or a `scanner.json` captured below. Each run saves its files in a new folder under `rae-exports`.

The first two URL settings use your established n8n paths. If you changed a path, copy the **Production URL** from the corresponding published Webhook node. For both header prompts, press Enter when that Webhook shows **Authentication → None**. For **Header Auth**, enter the webhook’s header name and its value when prompted. The model’s OpenRouter key belongs in Bryan’s n8n HTTP Request credential. [n8n Webhook guide](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/)

```powershell
& {
    $ErrorActionPreference = 'Stop'
    $py = '.\.venv\Scripts\python.exe'
    $intakeUrl = 'http://localhost:5678/webhook/cyberai-scanner-intake'
    $bryanUrl = 'http://localhost:5678/webhook/ai-report'

    function Read-WebhookAuth($workflow) {
        $name = (Read-Host "$workflow header name [Enter for None]").Trim()
        if (-not $name) { return @{ Name = $null; Value = $null } }
        $secret = Read-Host "$workflow header value" -AsSecureString
        return @{ Name = $name; Value = [System.Net.NetworkCredential]::new('', $secret).Password }
    }

    function Format-Risk($risk) {
        if ($null -eq $risk.risk_score) { return "Unavailable ($($risk.status))" }
        return "$($risk.risk_score) $($risk.risk_level)"
    }

    function Compare-Rating($reported, $expected) {
        if ($null -eq $reported -or $reported.PSObject.Properties.Name -notcontains 'risk_score') { return 'Missing in report' }
        return ($reported.risk_score -eq $expected.risk_score -and $reported.risk_level -eq $expected.risk_level)
    }

    # Confirm the RAE is ready and choose test or demo.
    $health = Invoke-RestMethod 'http://127.0.0.1:5001/api/rae/health' -TimeoutSec 10
    if ($health.status -ne 'ready') { throw 'Start the RAE in Terminal 1 first.' }
    $health | Format-Table | Out-Host
    $mode = (Read-Host 'Press Enter for TEST, or type DEMO').Trim()
    if ($mode -notin @('', 'test', 'demo')) { throw 'Choose TEST or DEMO.' }
    $demoMode = $mode -eq 'demo'
    $latest = Get-ChildItem -Path '.\rae-exports\run-*\scanner.json' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $defaultScan = '.\scan.json'
    if ($latest) { $defaultScan = $latest.FullName }
    if ($demoMode) { $defaultScan = 'live' }

    $runFolder = Join-Path '.\rae-exports' "run-$(Get-Date -Format yyyyMMdd-HHmmssfff)"
    New-Item -ItemType Directory -Force -Path $runFolder | Out-Null
    Write-Host "Files for this run: $runFolder"
    $scan = (Read-Host "Type LIVE or paste a raw scanner JSON path [Enter for $defaultScan]").Trim().Trim('"')
    if (-not $scan) { $scan = $defaultScan }

    # Capture one fresh scan if requested, then keep the raw JSON for replay.
    if ($scan -eq 'live') {
        $url = (Read-Host 'Enter the prechecked HTTP or HTTPS URL you are authorised to scan').Trim()
        if ($url -notmatch '^https?://') { throw 'Enter a complete HTTP or HTTPS URL.' }
        $body = @{ url = $url } | ConvertTo-Json
        $raw = Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:5000/api/scan' -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 120
        $scan = Join-Path $runFolder 'scanner.json'
        $raw | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $scan -Encoding utf8
    }
    if (-not (Test-Path -LiteralPath $scan -PathType Leaf)) { throw 'Raw scanner JSON file not found.' }
    $raw = Get-Content -LiteralPath $scan -Raw | ConvertFrom-Json
    if (-not $raw.url -or -not $raw.checks -or $null -eq $raw.findings) { throw 'Choose a raw scanner JSON file with url, checks and findings.' }
    if ($demoMode) { Write-Host "Website being assessed: $($raw.url)" }

    # Send the same scanner evidence through the RAE intake.
    $intakeAuth = Read-WebhookAuth 'Scanner intake'
    $env:CYBERAI_N8N_SCAN_WEBHOOK_URL = $intakeUrl
    $env:CYBERAI_N8N_HEADER_NAME = $intakeAuth.Name
    $env:CYBERAI_N8N_HEADER_VALUE = $intakeAuth.Value
    $frameworks = if ($demoMode) { @('csa') } else { @('csa', 'owasp') }
    foreach ($framework in $frameworks) {
        $file = Join-Path $runFolder "rae-only-$framework-receipt.json"
        & $py .\send_scan.py $scan --framework $framework --input-origin user_supplied_scan --output $file
        if ($LASTEXITCODE -ne 0) { throw "Intake failed for $framework. Check the n8n execution." }

        $receipt = Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
        $result = $receipt.response.assessment
        if ($receipt.http_status -ne 200 -or $result.scoring_framework.id -ne $framework -or $result.engine_version -ne $health.engine_version) {
            throw "The receipt did not contain the expected $framework assessment. Check the scanner intake URL and n8n response."
        }
        if ($framework -eq 'csa') { $csaAssessment = $receipt.response }
        [pscustomobject]@{
            Framework = $result.scoring_framework.id
            Engine    = $result.engine_version
            HTTP      = $receipt.http_status
            Findings  = $result.findings.Count
            Visitor   = Format-Risk $result.perspectives.visitor.overall_risk
            Owner     = Format-Risk $result.perspectives.website_owner.overall_risk
        } | Format-Table -AutoSize | Out-Host
    }

    # Show the separate, labelled 6/25 example during the presentation.
    if ($demoMode) {
        $demoFile = Join-Path $runFolder 'csa-scoring-demo-receipt.json'
        & $py .\rae_scoring_demo.py --output $demoFile
        if ($LASTEXITCODE -ne 0) { throw 'Check that rae_scoring_demo.py is beside stage2_engine.py.' }
        $demo = Get-Content -LiteralPath $demoFile -Raw | ConvertFrom-Json
        $demo.assessment.perspectives.visitor.overall_risk.rating_reasons | Format-List | Out-Host
    }

    # Optionally send the completed real CSA assessment to Bryan.
    if ((Read-Host 'Send the real CSA assessment to Bryan? [y/N]').Trim() -eq 'y') {
        $bryanAuth = Read-WebhookAuth 'Bryan report'
        $headers = @{}
        if ($bryanAuth.Name) { $headers[$bryanAuth.Name] = $bryanAuth.Value }
        $body = $csaAssessment | ConvertTo-Json -Depth 100 -Compress
        $reply = Invoke-RestMethod -Method Post -Uri $bryanUrl -Headers $headers -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 180
        if (-not $reply.report) { throw 'Expected a Bryan report. Check the report webhook URL.' }
        $bryanFile = Join-Path $runFolder 'bryan-csa-receipt.json'
        $reply | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $bryanFile -Encoding utf8
        $expected = $csaAssessment.assessment.perspectives
        [pscustomobject]@{
            Status       = $reply.status
            Website      = $reply.report.url
            Framework    = if ($reply.report.scoring_framework.id) { $reply.report.scoring_framework.id } else { 'Missing in report' }
            VisitorMatch = Compare-Rating $reply.report.visitor_view.overall_risk $expected.visitor.overall_risk
            OwnerMatch   = Compare-Rating $reply.report.website_owner_view.overall_risk $expected.website_owner.overall_risk
            AIUsed       = "$($reply.debug.ai_entries_used)/$($reply.debug.ai_entries_expected)"
        } | Format-List | Out-Host
    }
}
```

## What to explain during the demo

| Command or output | How to explain it to Rosita |
| --- | --- |
| Terminal 1 `rae_api.py` and Terminal 3 `/api/rae/health` | “This starts the risk engine and checks which version is ready.” |
| Terminal 2 `app.py` and Terminal 3 `/api/scan` | “I submit one authorised URL. The local scanner records what it observes and PowerShell saves the raw JSON.” When replaying, say “This is the response I saved during rehearsal.” |
| Terminal 3 `send_scan.py` | “n8n forwards the raw observations to the RAE. The receipt shows the chosen framework, the findings, and separate visitor and owner results.” In test mode, the same input goes through both CSA and OWASP. |
| Terminal 3 `rae_scoring_demo.py` | “For this labelled synthetic example, likelihood is **3**, and the highest impact rating is **2**. CSA multiplies them, so the visitor score is **6/25, Medium**. The receipt explains all six ratings.” |
| Optional Bryan request | “Bryan receives the completed CSA assessment and explains its findings. The report webhook is `http://localhost:5678/webhook/ai-report`. The assessed website comes from the RAE receipt. Our last successful check used the saved assessment for `https://footyroom.co/`.” |

**What success looks like.** On the current build, test mode prints `csa` and `owasp` with HTTP `200` and engine `0.4.0`. Demo mode prints the real scan’s result and the separate **6/25 Medium** example. A real score can be **Unavailable** when evidence or a scoring rule is missing. In Bryan’s output, `Status = ok` and a positive `AIUsed` count show that the workflow accepted model-written explanations. For the score handoff, check for framework `csa` and `True` on both perspective matches. Your last Bryan run showed `2/2` AI explanations and a blank framework, so check this separately.

## Workflow setup and quick fixes

| Where | Setting or check |
| --- | --- |
| **CyberAI Scanner to RAE - Local Prototype** | Use its Production URL at `/webhook/cyberai-scanner-intake` for Terminal 3. **Assess scan with RAE** calls `http://host.docker.internal:5001/api/rae/assess` from Docker, uses Header Auth `X-CyberAI-Token`, and forwards the whole `$json.body`. **Return RAE assessment** returns the RAE output as JSON. Setup export is `n8n\CyberAI_Scanner_Intake.json`. |
| **Postman TEST 1** or **CyberAI Bryan Report** | Use its report Production URL at `/webhook/ai-report`. Bryan’s HTTP Request uses the OpenRouter credential with `Authorization: Bearer <key>`. If the report omits the framework, check the published **Check Reply** code for `scoring_framework: scoring`. The scoring-aware export is `n8n\CyberAI_Bryan_Report.json`. Use a unique webhook path if you import it as a test copy. |
| Combined workflow at `/webhook/cyberai-scanner-intake-bryan-test` | It starts with raw scanner evidence and calls Bryan downstream. For this guide, use the standalone scanner intake for scoring and the report webhook for the finished assessment. |
| `400` mentioning the intake contract | Check that a raw scan went to the scanner intake. Send finished assessments to Bryan’s report webhook. |
| `401` at **Assess scan with RAE** | Match the node’s `X-CyberAI-Token` to the RAE token loaded in Terminal 1. |
| `401` at Bryan’s model **HTTP Request** | Check the OpenRouter credential selected on that node in the published workflow. |

## Optional offline URLhaus replay

Use the input ZIP and `cyberai-api-backend\clean_urls.csv` in the project folder. The batch replays reputation evidence and makes zero requests to the listed websites.

```powershell
$out = ".\Bryan_RAE_URLhaus_$(Get-Date -Format yyyyMMdd-HHmmss)"
.\.venv\Scripts\python.exe .\rae_batch.py '.\full Malicious URLs.csv.zip' --output $out
Get-Content -LiteralPath (Join-Path $out 'summary.json') -Raw
```

## Scoring and evidence limits

CSA uses the rounded mean of three likelihood ratings, the highest of three impact ratings, and a 5×5 matrix. OWASP uses its own factor averages and severity bands. CyberAI also shows the OWASP product as a ranking number out of 81. See [the intake contract](docs/INTAKE_CONTRACT.md), [the RAE output contract](docs/CONTRACT.md), [CSA’s risk assessment guide](https://isomer-user-content.by.gov.sg/36/016e3838-a9e5-4c6e-a037-546e8b7ad684/Guide-to-Conducting-Cybersecurity-Risk-Assessment-for-CII.pdf), [OWASP Risk Rating](https://community.owasp.org/OWASP_Risk_Rating_Methodology), and [OWASP ASVS 5.0.0](https://asvs.owasp.org/).

## Automatic scanner → RAE → Bryan

Use [the live handoff walkthrough](docs/LIVE_HANDOFF.md) to send a fresh scan automatically. It includes a public HTTP test page and an optional CSA scenario estimate based on the recorded response and clearly stated assumptions.
