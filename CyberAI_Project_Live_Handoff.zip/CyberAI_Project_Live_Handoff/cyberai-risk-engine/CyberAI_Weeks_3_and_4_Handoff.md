# CyberAI Major Project handoff for Weeks 3 and 4

## Request for the new chat

Help me finish my separate Week 3 and Week 4 individual progress documents. I will upload my Week 1 and Week 2 documents. Match their format, headings, tone, and level of detail. Use this handoff as technical evidence. Write in my voice and separate what I implemented, what I tested, and what is still pending. Preserve any blank supervisor section unless I provide approved feedback. If the dates on my templates differ from the dates below, ask me which dates to use. Do not backdate later tests into an earlier reporting week.

The Week 3 and Week 4 documents are overdue. I plan to submit them before my 11:15 a.m. meeting and want them ready by 11 a.m. Singapore time. The priority is an accurate progress report I can explain to my supervisor, Rosita.

## Project and my role

CyberAI is a prototype that assesses observable security evidence for a submitted website URL. Ziyad owns the scanner, I own the Python Risk Assessment Engine (RAE), and Bryan owns the AI explanation and reporting workflow. The scanner provides structured observations such as URL scheme, HTTP response, redirects, TLS, cookies, response headers, and reputation matches. The RAE validates the observations, applies the selected framework when there is enough evidence, and reports website-visitor and website-owner outcomes separately. Bryan’s workflow explains the findings at the chosen literacy level.

The agreed assessment scope is passive, surface-level checks. A timeout or incomplete observation is reported as such. The project can report an observed issue, identify missing evidence, and leave a score unavailable. Each assessment describes the responses the scanner actually captured.

## Week 1 and Week 2 anchor

- Week 1 was 19–25 October 2026 in the working schedule. This covered project architecture and component roles. Use my uploaded Week 1 document to confirm the exact wording.
- Week 2 was 26 October–1 November 2026. I took ownership of the RAE, started the Python implementation, and tested the CSA arithmetic and incomplete-scan handling. The early version used discoverability, exploitability and reproducibility for likelihood, then confidentiality, integrity and availability for impact. Use my uploaded Week 2 document for the exact tasks and results.

## Week 3 working period 2–8 November 2026

**Planned tasks 3.8–3.11.** Agree the scanner-to-RAE JSON structure and finding fields with Ziyad, define the RAE-to-AI output with Bryan, and work toward finalising the three-component data contract. These are project-plan tasks. My local tests show integration progress. Formal team sign-off on the complete contract still needs confirmation.

**Work completed and tested.**

- Defined how the RAE reads scanner JSON and distinguishes metadata, observed findings, missing evidence and contradictory checks. Kept visitor and website-owner perspectives separate.
- Set up a local Docker Desktop n8n instance and a Flask RAE endpoint. I tested the webhook from PowerShell and through the Python sender, then verified n8n executions and saved JSON responses. An initial webhook test returned 404 until I put the workflow into its listening state. A later sender test returned HTTP 200 after the workflow setup was corrected.
- Built the scanner-to-n8n handoff using a saved scanner response and a Python JSON sender. The intake event is `cyberai.scanner.result_ready`. The RAE returns `cyberai.rae.assessment_ready` with structured findings and separate visitor and owner results. Verified that a replay of a timeout could produce an incomplete or insufficient-evidence assessment with blank scores.
- Used the scanner’s structured JSON as the input for the RAE. During this period, manual forwarding of saved JSON was still part of the local workflow. Preserve the difference between a successful manual replay, automatic scanner forwarding, and a complete Bryan report.
- Created or exercised version-control history and tested local Flask, n8n and PowerShell integration. Keep actual GitHub branch publication and merge status separate from local work.

## Week 4 working period 9–15 November 2026

**Planned tasks 3.12–3.14.** Research CSA, OWASP and NIST criteria, implement and test evidence-based rules, and work toward launching the first rule that produces a supported rating. The released scoring choices are CSA 5×5 and OWASP Risk Rating. Early research considered NIST. Only describe a rule as operational to the extent that a verified example supports it.

**Work completed and tested.**

- Researched CSA’s likelihood and impact method and the OWASP Risk Rating Methodology. Implemented two selectable calculations. CSA rounds the mean of the three likelihood factors, uses the highest of the three impact factors, and multiplies likelihood by impact for a score out of 25. OWASP uses its own factor values, averages and severity bands. CyberAI also exposes a product out of 81 as a local ranking number in OWASP mode.
- Used OWASP Application Security Verification Standard (ASVS) references to link findings to related controls. For example, the HTTP observation references ASVS 5.0.0 requirement 12.2.1 on encrypted connections. The current rule supports the discovery factor when the scanner records a successful plain HTTP response without a redirect. A full score requires more evidence about the threat and impact.
- Reused Ziyad’s newer scanner with the batch-compatible changes, merged it with the RAE scoring update, and packaged the result as `CyberAI_Project_Merged.zip`. The merged project includes RAE 0.4.0, the scanner, the offline batch script, the workflow exports, and a short setup guide. Old duplicate files, tests and previous test outputs were removed from the active distribution.
- Verified the published CSA 5×5 matrix and all nine OWASP severity combinations against the numerical implementation. A later rerun of the merged verification suite passed 67 checks. The arithmetic cases use explicitly supplied factors. With CSA likelihood ratings 3, 2 and 3, and impact ratings 2, 1 and 1, the calculator returns 3 for likelihood, 2 for impact and **6/25 Medium**. This is a calculator test, so do not describe it as a scored public scan.
- Ran the original URLhaus export offline through the scanner’s URL reputation lookup and RAE. The export had **169,054 rows**. The batch processed **112,832** rows marked online at export and skipped **56,222** marked offline. There were **112,784** exact lookup matches, **48** unmatched rows, and **0 rejected rows**. Every processed row was classified as `offline_only`. The 0.4.0 run assigned **zero numerical RAE scores**. The data is useful for reviewing reputation findings, handling of missing evidence and report validation. The existing shareable `Bryan_RAE_URLhaus.zip` was generated with 0.2.2, and a separate 0.4.0 replay was verified locally.

## Verified follow-up on 16 November and current status

- Windows PowerShell returned `0.4.0 cyberai-rae ready` from `/api/rae/health`. Both saved-scan runs through the published RAE-only n8n intake returned HTTP 200, engine 0.4.0, and the requested framework. The receipts use the exact same scan input. Keep this follow-up outside the Week 4 date range unless the template asks for status at submission.
- Both receipts contained **13 observations**. One was the informational hostname, ten cookie observations lacked structured supporting details, and two header findings needed scoring rules. The visitor and website-owner scores were both `null`. The earlier erroneous replays used the reporting route and returned a fallback report where the RAE fields were absent. The standalone intake retest resolved that routing issue.
- The reporting workflow in n8n is **Postman TEST 1**. It accepts the finished RAE assessment at the report webhook, usually `/webhook/ai-report`. The scanner intake and combined workflow start from raw scanner evidence. An HTTP 200 fallback report had no useful findings and recorded a 401 at the model call. The old OpenRouter key also returned 401 in a direct check. Bryan said the token had reset, and I obtained a replacement. Its acceptance, selection in n8n and a new report run still need verification.
- The combined scanner-to-RAE-to-Bryan path needs a current successful run. Check that Bryan’s report preserves the selected framework and both perspectives. A local check of the bundled report node preserved both blank scores using a mocked model reply, which verifies the report mapping.
- The updated `README.md` explains the three-terminal live setup, saved-scan replay, which webhook to use, and success checks for CSA and OWASP. A GitHub branch named `rae-merged-update` holds the old tracked project archive. At the last check on 16 November it contained the archive only. Verify the branch and pull request before claiming that the merged code was published or merged to `main`.

- On 16 November I approved a separate synthetic CSA demo for the presentation. The demo script ran against RAE 0.4.0 and produced a visitor score of **6/25 Medium**, with likelihood **3**, impact **2**, and a reason for each of the six factors. The site-owner score was unavailable because the demo only supplied visitor context. This is a labelled example. For the presentation I also want a prechecked live scan, and the URL and evidence still need confirmation.

## Current gaps and suggested next order

1. Choose an authorised URL and rehearse the real scan. Present the synthetic numerical demo as its own result and report the live scan only to the level supported by its evidence. Real automatic scoring needs a reviewed rule and enough evidence about likelihood and consequences. The current intake does not yet accept a structured questionnaire or reviewed context alongside the scan.
2. Submit the Week 3 and Week 4 documents using this evidence. Mention progress and open scope accurately.
3. Validate Bryan’s replacement OpenRouter key and run one clean report from a saved RAE assessment. Then assemble the offline batch handoff in the intended RAE version and let Bryan know the outputs contain reputation observations and evidence statuses rather than labelled numerical risk scores.
4. Set aside time before the 11:15 meeting to rehearse the demo and presentation. Ask Rosita which real-world finding to score next and what scanner, visitor and owner evidence the team will treat as verified.

### Technical references

- [CSA Guide to Conducting Cybersecurity Risk Assessment for CII](https://isomer-user-content.by.gov.sg/36/016e3838-a9e5-4c6e-a037-546e8b7ad684/Guide-to-Conducting-Cybersecurity-Risk-Assessment-for-CII.pdf), Sections 4.2–4.3 and Figures 3–5.
- [OWASP Risk Rating Methodology](https://community.owasp.org/OWASP_Risk_Rating_Methodology).
- [OWASP ASVS 5.0.0](https://asvs.owasp.org/).
