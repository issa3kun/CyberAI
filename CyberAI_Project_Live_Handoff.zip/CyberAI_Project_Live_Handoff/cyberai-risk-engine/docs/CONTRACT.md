# CyberAI Assessment Contract

Version 0.4.0 prepares separate assessments for visitors and website owners from the scanner evidence.

## Scanner input

The adapter expects a JSON object with `url`, `checks.live_response` and a `findings` list. It can process the body returned by Ziyad's `/api/scan`, including the extra API envelope fields. API validation-rejection bodies lacking scanner data are rejected, not classified as Low risk.

| Field | Expected content |
| --- | --- |
| `url` | Submitted HTTP/HTTPS URL, without embedded credentials |
| `checks.https_in_submitted_url` | Boolean or null |
| `checks.live_response.request_completed` | Boolean or null; API success is not a substitute |
| `checks.live_response.http_status_code` | Integer 100-599 or null |
| `checks.live_response.tls_connection_verified` | Boolean or null; generic connection errors do not establish a certificate problem |
| `checks.live_response.security_headers` | Named Boolean/null observations for CSP, content-type options, HSTS and framing protection |
| `checks.live_response.cookies_detected` | Whether Set-Cookie headers were observed on the initial response |
| `checks.live_response.cookies` | Cookie name and Secure, HttpOnly, SameSite attributes; no values |
| `checks.live_response.redirect_detected` | Boolean or null |
| `checks.live_response.redirect_target_scheme` | Observed target scheme, if reported; not an inspected destination |
| `checks.redirect_assessment` | Optional redirect chain with status, hops and the last response or offline target report in `final_result` |
| `findings[].id` | Stable scanner finding ID |
| `findings[].evidence` | Scanner-supplied observation text, treated as untrusted data |
| `findings[].limitation` | Optional scanner-supplied limitation |
| `findings[].severity` | Scanner label retained for traceability; never an RAE score |
| `findings[].threat_category` | Optional category for an exact threat-list match |

Missing observations remain unavailable. Invalid Booleans are not converted by truthiness. A finding claiming a missing header cannot be accepted as consistent evidence when its corresponding check says the header is present.

The RAE excludes `server_header_present` from its evidence contract for compatibility with older scanner reports. Raw header values, owner asset context and structured links from cookie findings to particular cookies are not available in the present input contract.

## Assessment output

`assess_scan` returns scanner scope, findings, validation issues, limitations and two independent perspective objects. `input_sha256` identifies the exact input content; it is not a unique job ID or a measure of evidence truth.

| Path | Meaning |
| --- | --- |
| `scan.status` | Assessment outcome, including whether the scanner used offline evidence |
| `scan.http_response_received` | Whether consistent evidence supports a received response |
| `scan.scope` | Offline evidence, the initial response, or the initial response and recorded redirect chain |
| `scan.destination_assessed` | True when the scanner recorded a successful and consistent destination response |
| `scan.redirect_assessment` | Optional chain status, followed and unfollowed hops, final URL and normalized `final_response`. The top-level scan fields continue to describe the initial response. |
| `findings[].finding_ref` | Stable position-based reference within this report; duplicate IDs are retained |
| `findings[].validation_status` | Handling state of the observation |
| `findings[].threat_category` | Recognized scanner category for a threat-list match, when supplied |
| `findings[].response_scope`, `findings[].observed_url` | Present for a recorded chain to identify which response supplied each finding. Initial finding references are retained, and destination finding references continue the sequence. |
| `scoring_framework` | Selected CSA or OWASP scoring method, source and score scale |
| `findings[].control_references` | Applicable OWASP ASVS requirement, version and scanner coverage |
| `findings[].scoring_evidence` | Observed facts and missing inputs for findings matched by a scenario rule |
| `findings[].perspectives.visitor` | Visitor factors, reasons and nullable score |
| `findings[].perspectives.website_owner` | Website owner factors, reasons and nullable score |
| `perspectives.visitor.overall_risk` | Overall visitor assessment status and nullable rating |
| `perspectives.website_owner.overall_risk` | Overall owner assessment status and nullable rating |
| `validation_issues` | Invalid fields, contradictory observations and known scanner limitations |
| `scanner_preliminary_assessment` | Non-authoritative scanner summary; `used_for_scoring` is false |

The RAE uses the selected framework's calculation when all required factors are supported. The highest supported score is reported per perspective with the contributing finding, evidence, reasons and unscored finding references. See [Scoring and evidence limits](../README.md#scoring-and-evidence-limits) for current finding-rule coverage.

## Status meanings

| Scan status | Meaning |
| --- | --- |
| `completed_initial_response` | Initial response available for the limited scanner checks; not proof of website safety |
| `completed_redirect_destination` | The scanner recorded a successful final response and the RAE accepted its surface-check evidence |
| `offline_only` | The scanner deliberately skipped the live request and recorded an offline finding |
| `partial` | A redirect chain is unfinished or the inspected response leaves evidence incomplete |
| `failed` | Request failed or did not complete, without contradictory input |
| `incomplete` | Request outcome or response metadata is insufficient |
| `inconsistent` | Invalid or contradictory input was detected |

| Finding status | Meaning |
| --- | --- |
| `informational` | Metadata or redirect observation, not a scored scenario |
| `reputation_match` | The scanner reported an exact match in its configured threat list. The current response and CSA impact are unverified. |
| `needs_rule` | A recognized observation exists; reviewed scoring is still required |
| `incomplete` | Response-dependent finding or recorded request failure lacks a completed HTTP assessment |
| `insufficient_evidence` | Required textual or structured evidence is unavailable |
| `conflicting_evidence` | Finding contradicts its supporting checks or scope |
| `unsupported` | No handler exists for the ID; observation remains visible |

Overall statuses describe why a rating is unavailable: `needs_rules`, `insufficient_evidence`, `invalid_evidence`, `unsupported_findings` or `not_assessed`. `null` means unavailable. A redirect stopped by a reputation match has `redirect_assessment.status = "threat_list_match"` and `destination_assessed = false`. The target's offline report is under `final_response`.

## Webhook envelope

`build_webhook_payload` wraps an assessment. It does not deliver it.

| Field | Meaning |
| --- | --- |
| `event` | `cyberai.rae.assessment_ready` |
| `contract_version` | `cyberai.rae.webhook/0.2.0-draft` |
| `scan_id` | Optional ID supplied by the caller; null until one is provided |
| `input_origin` | `user_supplied_scan`, `synthetic_test_data` or `unspecified` |
| `is_synthetic_test_data` | True for explicit synthetic input, false for a user-supplied scan, null when origin is unspecified |
| `report_preferences.literacy_level` | Pass-through frontend/team label; default unspecified |
| `report_preferences.perspectives` | Visitor and website_owner |
| `assessment` | Structured RAE output |
| `report_requirements` | Proposed report-preservation requirements, not an enforcement mechanism |

Bryan should explain recorded observations, missing evidence and limitations. He should not invent error causes, treat preliminary scanner labels as final ratings, replace nulls with Low, merge the two perspectives or calculate scores with the LLM.

