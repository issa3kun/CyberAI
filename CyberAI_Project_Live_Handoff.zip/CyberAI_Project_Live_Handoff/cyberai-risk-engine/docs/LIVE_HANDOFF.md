# CyberAI live handoff

Use the new copy of `cyberai-risk-engine` so you can keep your previous setup available. This package includes the scanner update, Python scripts, and n8n workflow exports. For a reputation lookup or batch run, copy your existing `clean_urls.csv` into `cyberai-api-backend`. Your existing URLhaus ZIP is only needed for the offline batch. If the scanner cannot read a configured dataset, the reputation lookup reports `unavailable`.

The demo uses [BadSSL's plain HTTP test page](http://http.badssl.com/). It's a public test page for an unencrypted connection. Use the URL exactly as shown and submit it once from PowerShell. The [BadSSL project](https://github.com/chromium/badssl.com) describes the site as a manual test service. Use a normal HTTP response from the page for the demo. If the response redirects, fails, or is skipped, the scenario estimate is absent. A successful intake HTTP status describes the webhook response. Check `assessment.scan.http_status_code` to see what the target returned.

## 1. Configure the two n8n workflows once

Start your existing n8n Docker instance. Import these two files into it. These workflows use new webhook paths so your earlier manual workflow can still run.

| Workflow | Node | Set in n8n |
| --- | --- | --- |
| `n8n/CyberAI_Live_Bryan_Report.json` | **Webhook** | Header Auth credential for the report. Use the same credential in the next workflow's **Send assessment to Bryan** node. |
| Same report workflow | **HTTP Request** | Bryan's OpenRouter Header Auth credential, with header `Authorization` and value `Bearer <key>`. Confirm the approved model with Bryan. The export retains the model in his supplied workflow. |
| `n8n/CyberAI_Live_Handoff.json` | **Receive scanner result** | Scanner intake Header Auth credential. The commands below assume its header name is `X-CyberAI-Intake`. |
| Same handoff workflow | **Assess scan with RAE** | Header Auth with header name `X-CyberAI-Token` and the RAE token loaded in Terminal 1. The Docker Desktop URL is `http://host.docker.internal:5001/api/rae/assess`. For n8n running directly on Windows, use `http://127.0.0.1:5001/api/rae/assess`. |
| Same handoff workflow | **Send assessment to Bryan** | Select the report Header Auth credential. `http://127.0.0.1:5678/webhook/cyberai-live-report` assumes both workflows run on the same standard n8n instance. For a separate instance, use Bryan's actual Production URL. |

Publish the report workflow first and then publish the handoff workflow. Take the intake URL from the **Production URL** tab of **Receive scanner result**. The scanner receives the RAE JSON first. The handoff then continues to Bryan in n8n. The final **Check Bryan report** node checks that the report kept the scan ID, framework, scores, and the separate hypothesis.

If Ziyad runs the scanner on a different laptop, give him a team-accessible HTTPS intake URL and its intake credential privately. Send both from Terminal 2 on his laptop. His own `localhost` reaches his own machine. For the first run, running n8n, the scanner, and the RAE on one laptop avoids the need for cross-machine access.

## 2. Terminal 1 starts the RAE

Open PowerShell in the extracted `cyberai-risk-engine` directory. Leave the terminal open. The last command enables the optional visitor estimate only for the exact demo URL. Omit the final option and URL when you want only the ordinary assessment.

```powershell
if (-not (Test-Path '.\.venv\Scripts\python.exe')) { python -m venv .venv }
$py = '.\.venv\Scripts\python.exe'
& $py -m pip install -r .\requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
if (-not $env:CYBERAI_RAE_API_TOKEN) {
    $env:CYBERAI_RAE_API_TOKEN = [Environment]::GetEnvironmentVariable('CYBERAI_RAE_API_TOKEN', 'User')
}
if (-not $env:CYBERAI_RAE_API_TOKEN) {
    $env:CYBERAI_RAE_API_TOKEN = [System.Net.NetworkCredential]::new('', (Read-Host 'Paste the RAE token' -AsSecureString)).Password
}
& $py .\rae_api.py --host 0.0.0.0 --port 5001 --demo-scenario-url 'http://http.badssl.com/'
```

## 3. Terminal 2 starts Ziyad's scanner

Start this terminal from the same project folder. These commands assume Terminal 1 has installed the dependencies. If Ziyad runs on a separate machine, first create a virtual environment and install the requirements there too. The AdaBoost and SHAP dependencies are optional for this demonstration. Their model output is separate from the CSA score.

```powershell
$env:CYBERAI_N8N_SCAN_WEBHOOK_URL = 'http://localhost:5678/webhook/cyberai-live-scan'
$env:CYBERAI_N8N_HEADER_NAME = 'X-CyberAI-Intake'
$env:CYBERAI_N8N_HEADER_VALUE = [System.Net.NetworkCredential]::new('', (Read-Host 'Paste the scanner intake token' -AsSecureString)).Password
.\.venv\Scripts\python.exe .\cyberai-api-backend\app.py
```

## 4. Terminal 3 submits one scan and prints the scan ID

Run this on the scanner's computer. Change the `$url` line to submit a different authorised URL, or change `framework = 'csa'` to `framework = 'owasp'` to use the separate OWASP mode. The optional estimate is CSA-only.

```powershell
$url = 'http://http.badssl.com/'
$body = @{ url = $url; framework = 'csa' } | ConvertTo-Json -Compress
$scan = Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:5000/api/scan' -ContentType 'application/json' -Body $body -TimeoutSec 120 -ErrorAction Stop
$scan.scan_id
$scan.checks.live_observation | Select-Object state, reason_code, http_status_code, tls_connection_verified
```

1. In n8n **CyberAI Live Scan to RAE and Bryan → Executions**, open the run whose **Receive scanner result** node shows that scan ID. **Check scan identity** should show the same ID, target and framework from the RAE. A scanner HTTP 200 alone cannot confirm delivery. If the run is missing, check Terminal 2 for a warning with the scan ID.
2. In the RAE output, show `assessment.perspectives.visitor.overall_risk` and `website_owner.overall_risk` for the actual scan. With the current scoring rules a plain HTTP response supplies discoverability = 3. The remaining evidence gaps can leave both totals unavailable.
3. Show `assessment.scenario_estimate` below the regular assessment. Its visitor-only estimate of **6/25 (Medium)** uses the observed HTTP response plus a stated hypothetical event. If a similar page returned a routine contact email and a moderately skilled observer could repeatedly see the traffic, D/E/R = 3/3/3 and C/I/A = 2/1/1. Likelihood 3 × impact 2 gives 6. No personal data needs to be submitted during the demo.
4. Open **Check Bryan report** and confirm `ratings_preserved: true`. Under `report.scenario_estimate`, `explanation_source: ai_selected` means Qwen selected one of two exact sentences supplied by the RAE. `standard` means the workflow used the RAE wording after an unusable or unavailable model reply. `report_status: fallback` means you still have the RAE assessment but need to check Bryan's workflow and model credential.

For a real threat-list entry, the scanner can skip the connection and return the local list match with an unavailable framework score. That branch shows reputation reporting. The public HTTP page shows the live transport observation. The labelled hypothesis demonstrates the calculation and report validation.

For manual replay use the original README and its original webhook paths. The new intake expects both the raw evidence and its scanner-generated scan ID. For current report checks use the new report workflow. The old Bryan workflow is preserved for manual use.
