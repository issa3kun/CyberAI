"""Map structured scanner observations to supported risk factors."""

from urllib.parse import urlsplit

from scoring_methods import (
    CSA_IMPACT, CSA_LIKELIHOOD, OWASP_LIKELIHOOD, OWASP_TECHNICAL_IMPACT,
    score_supported_factors,
)

HTTP_RULE_ID = "cleartext_http_response_v1"
CSA_REASONS = {
    "exploitability": "The scan did not establish the access or technical skills needed to interfere with a visitor's traffic.",
    "reproducibility": "One recorded response does not establish how consistently the threat event can occur.",
    "confidentiality": "The scan did not inspect what information was sent or determine its sensitivity.",
    "integrity": "The scan did not verify what changing the response could affect.",
    "availability": "The scan did not establish the effect on access to the website or its services.",
}
OWASP_REASONS = {
    "skill_level": "The scan did not establish the skills of a potential threat group.",
    "motive": "The scan did not establish the potential value of the exchanged data to a threat group.",
    "opportunity": "The scan did not establish who could observe the relevant network traffic.",
    "size": "The scan did not establish the size of the group with the required access.",
    "ease_of_exploit": "The scan did not establish how easily someone could interfere with a visitor's traffic.",
    "awareness": "The scan did not establish what a relevant threat group knows about this site.",
    "intrusion_detection": "The scan did not inspect application or network monitoring.",
    "loss_of_confidentiality": "The type, quantity and sensitivity of exposed information are unknown.",
    "loss_of_integrity": "The potential extent and consequences of changes to data are unknown.",
    "loss_of_availability": "The services that could be interrupted and their importance are unknown.",
    "loss_of_accountability": "The scan did not establish whether a threat event could be attributed to an individual.",
}


def http_transport_evidence(finding, response, framework):
    """Evaluate the risks of a successful plain HTTP exchange using scanner facts."""
    if finding["id"] != "https_not_used" or finding["validation_status"] != "needs_rule":
        return None
    if urlsplit(response["url"]).scheme != "http":
        return None
    status_code = response["http_status_code"]
    evidence = {
        "url": response["url"],
        "submitted_scheme": "http",
        "http_response_received": response["http_response_received"],
        "http_status_code": status_code,
        "redirect_detected": response["redirect_detected"],
        "tls_connection_verified": response["tls_connection_verified"],
    }
    if (response["http_response_received"] is not True
            or not (status_code is not None and 200 <= status_code < 300)
            or response["redirect_detected"] is not False
            or response["redirect_target_scheme"] is not None
            or response["tls_connection_verified"] is not None):
        return {
            "evidence": evidence,
            "observation": "The submitted URL uses HTTP.",
            "missing_evidence": ["A successful initial HTTP response without a redirect."],
        }

    scenario = {
        "rule_id": HTTP_RULE_ID,
        "evidence": evidence,
        "observation": "The scanner recorded a successful HTTP response without a redirect. The exchange lacked TLS protection.",
        "risk_scenario": "An observer with access to the connection could read the exchange. A party able to alter it could change the response.",
    }
    if framework == "csa":
        likelihood = dict.fromkeys(CSA_LIKELIHOOD)
        likelihood["discoverability"] = 3
        impact = dict.fromkeys(CSA_IMPACT)
        reasons = {
            "discoverability": "3 (Possible), using CyberAI's surface-check interpretation of CSA Figure 3. Examining the recorded HTTP exchange showed the transport weakness. The attacker access conditions remain unverified.",
            **CSA_REASONS,
        }
    else:
        likelihood = dict.fromkeys(OWASP_LIKELIHOOD)
        likelihood["ease_of_discovery"] = 9
        impact = dict.fromkeys(OWASP_TECHNICAL_IMPACT)
        reasons = {
            "ease_of_discovery": "9 (Automated tools available). The scanner automatically identified a successful cleartext exchange from the response metadata.",
            **OWASP_REASONS,
        }
    scenario.update(
        likelihood_factors=likelihood, impact_factors=impact,
        rating_reasons=reasons, missing_evidence=[
            name for name, value in {**likelihood, **impact}.items() if value is None
        ],
    )
    return scenario


def rate_observed_finding(finding, response, framework):
    """Attach supported inputs and give each perspective its own evidence status."""
    scenario = http_transport_evidence(finding, response, framework)
    if scenario is None:
        return
    finding["scoring_evidence"] = scenario
    if "likelihood_factors" not in scenario:
        for view in finding["perspectives"].values():
            view.update(
                status="insufficient_evidence",
                reason=f"{scenario['observation']} A successful HTTP response without a redirect is required for this rule.",
                evidence=scenario["evidence"].copy(),
            )
        return

    likelihood = scenario["likelihood_factors"]
    impact_key = "cia" if framework == "csa" else "owasp_impact_factors"
    for perspective, view in finding["perspectives"].items():
        affected_party = "the visitor" if perspective == "visitor" else "the website owner"
        impact = scenario["impact_factors"].copy()
        result = score_supported_factors(framework, likelihood, impact)
        reason = (f"All required factors for {affected_party} are supported by the scanner evidence."
                  if result is not None else
                  f"A numerical score for {affected_party} requires evidence about the threat event and its consequences.")
        view.update(
            status="scored" if result is not None else "insufficient_evidence",
            reason=f"{scenario['observation']} {reason}",
            rule_id=scenario["rule_id"],
            evidence=scenario["evidence"].copy(),
            rating_reasons=scenario["rating_reasons"].copy(),
            likelihood_factors=likelihood.copy(),
        )
        view[impact_key] = impact
        if result is not None:
            view.update(result)
