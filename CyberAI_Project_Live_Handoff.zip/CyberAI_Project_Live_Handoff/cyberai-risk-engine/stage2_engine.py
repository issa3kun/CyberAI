"""Assess scanner evidence for visitors and website owners."""

import copy
import hashlib
import json
from urllib.parse import urlsplit

from finding_evidence import rate_observed_finding
from owasp_references import control_reference
from scoring_methods import FRAMEWORKS, SEVERITY_ORDER, validate_framework

ENGINE_VERSION = "0.4.0"
CONTRACT_VERSION = "cyberai.rae.webhook/0.2.0-draft"
PERSPECTIVES = ("visitor", "website_owner")
FAILURE_IDS = {"request_timeout", "connection_error", "tls_verification_failed"}
OFFLINE_IDS = {"threat_list_match", "live_scan_skipped"}
THREAT_CATEGORIES = {"malware", "phishing", "unwanted_software"}
REDIRECT_STATUSES = {301, 302, 303, 307, 308}
CHAIN_STATUSES = {
    "completed", "blocked", "http_error", "invalid_redirect",
    "limit_reached", "loop_detected", "request_failed", "threat_list_match",
}
HEADER_CHECKS = {
    "missing_csp": "content_security_policy",
    "weak_x_content_type_options": "x_content_type_options",
    "missing_or_weak_hsts": "strict_transport_security",
    "missing_frame_protection": "frame_protection",
}
COOKIE_IDS = {
    "cookie_missing_secure", "cookie_missing_httponly", "cookie_missing_samesite",
    "cookie_invalid_samesite", "cookie_samesite_none_without_secure",
}
KNOWN_IDS = set(HEADER_CHECKS) | COOKIE_IDS | FAILURE_IDS | OFFLINE_IDS | {
    "hostname_detected", "https_not_used", "redirect_detected", "https_redirects_to_http",
}


def _issue(issues, code, path, message, severity="warning"):
    issues.append({"code": code, "path": path, "severity": severity, "message": message})


def _boolean(obj, key, issues, path):
    value = obj.get(key)
    if value is not None and type(value) is not bool:
        _issue(issues, "invalid_boolean", f"{path}.{key}",
               "Expected true, false or null; this value is unavailable.", "error")
        return None
    return value


def _text(value):
    return value if isinstance(value, str) and value.strip() else None


def _validate_url(url):
    if not isinstance(url, str) or not url.strip():
        raise ValueError("Scanner result needs a non-empty URL string.")
    if any(ord(c) < 32 or ord(c) == 127 for c in url):
        raise ValueError("URL contains control characters.")
    url = url.strip()
    try:
        parsed = urlsplit(url)
        _ = parsed.port  # Access validates malformed or out-of-range port metadata.
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                or parsed.username is not None or parsed.password is not None
                or any(c.isspace() for c in parsed.netloc)):
            raise ValueError("Invalid HTTP/HTTPS URL.")
    except ValueError as exc:
        raise ValueError("Scanner result needs an HTTP/HTTPS URL without credentials.") from exc
    return url, parsed


def _validate_input(scan):
    if not isinstance(scan, dict):
        raise ValueError("Scanner result must be a JSON object.")
    url, parsed = _validate_url(scan.get("url"))
    checks = scan.get("checks")
    if not isinstance(checks, dict) or not isinstance(checks.get("live_response"), dict):
        raise ValueError("Stage 2 requires checks.live_response from Ziyad's current scanner.")
    findings = scan.get("findings")
    if not isinstance(findings, list):
        raise ValueError("Scanner findings must be a list.")
    for finding in findings:
        if not isinstance(finding, dict) or _text(finding.get("id")) is None:
            raise ValueError("Every finding must be an object with a non-empty string ID.")
    return url, parsed, checks, findings


def _cookie_details(live, detected, issues):
    raw = live.get("cookies", [])
    if not isinstance(raw, list):
        _issue(issues, "invalid_cookie_list", "checks.live_response.cookies",
               "Cookie details must be a list; they cannot be used.", "error")
        raw = []
    details = []
    for index, cookie in enumerate(raw):
        path = f"checks.live_response.cookies[{index}]"
        if not isinstance(cookie, dict) or _text(cookie.get("name")) is None:
            _issue(issues, "invalid_cookie_details", path,
                   "Cookie details need a non-empty name.", "error")
            continue
        same_site = cookie.get("samesite")
        if same_site is not None and not isinstance(same_site, str):
            _issue(issues, "invalid_cookie_samesite", path + ".samesite",
                   "SameSite observation must be a string or null.", "error")
            same_site = None
        # Never forward arbitrary cookie keys such as value or raw Set-Cookie.
        details.append({
            "name": cookie["name"],
            "secure": _boolean(cookie, "secure", issues, path),
            "httponly": _boolean(cookie, "httponly", issues, path),
            "samesite": same_site,
        })
    if detected is True and not details:
        _issue(issues, "cookie_details_missing", "checks.live_response.cookies",
               "Cookie headers were reported but parsed attributes are unavailable.")
    if detected is False and details:
        _issue(issues, "cookie_observations_conflict", "checks.live_response.cookies",
               "Cookie details exist although cookies_detected is false.", "error")
    return details


def _finding_status(finding, context):
    fid = finding["id"]
    if fid not in KNOWN_IDS:
        return "unsupported", "This finding ID has no reviewed handler."
    if fid == "tls_verification_failed":
        if context["scheme"] != "https" or context["tls_verified"] is not False:
            return "conflicting_evidence", "The TLS failure finding conflicts with the structured transport checks."
        return "incomplete", "The scanner recorded a failed TLS handshake or certificate verification."
    if fid in FAILURE_IDS:
        return "incomplete", "The scanner reported a request failure; its cause is limited to the recorded error."
    if fid == "hostname_detected":
        return "informational", "A detected hostname is metadata, not a scored risk."
    if _text(finding.get("evidence")) is None:
        return "insufficient_evidence", "The finding has no usable textual evidence."
    if fid in OFFLINE_IDS:
        if not context["offline_only"]:
            return "conflicting_evidence", "The offline finding conflicts with the recorded HTTP checks."
        if fid == "threat_list_match":
            return "reputation_match", "The scanner reported an exact match in its configured threat list. The current HTTP response and CSA impact are unverified."
        return "incomplete", "The scanner skipped the live HTTP request. The finding records why."
    if fid == "https_not_used":
        if context["scheme"] != "http":
            return "conflicting_evidence", "The submitted URL uses HTTPS but the finding says it does not."
        return "needs_rule", "HTTP was observed in the submitted URL; no reviewed risk scenario or scores exist."
    if context["response_received"] is not True:
        return "incomplete", "A consistent, completed HTTP response was not confirmed for this finding."
    if fid in HEADER_CHECKS:
        flag = context["headers"].get(HEADER_CHECKS[fid])
        if fid == "missing_or_weak_hsts" and context["scheme"] != "https":
            return "conflicting_evidence", "The scanner applies this HSTS check only to HTTPS responses."
        if flag is True:
            return "conflicting_evidence", "The check reports protection present but the finding reports it absent or weak."
        if flag is None:
            return "insufficient_evidence", "The supporting structured header-check result is unavailable."
        return "needs_rule", "An initial-response control observation exists; exploitability and impact are not established."
    if fid in COOKIE_IDS:
        if context["cookies_detected"] is False:
            return "conflicting_evidence", "A cookie issue was reported but the scanner says no cookies were detected."
        if context["cookies_detected"] is not True or not context["cookies"]:
            return "insufficient_evidence", "Cookie attribute details needed to review this finding are unavailable."
        return "needs_rule", "Cookie attributes are available, but cookie purpose and a reviewed harm scenario are not established."
    if fid in {"redirect_detected", "https_redirects_to_http"}:
        if context["redirect_detected"] is not True or context["http_status_code"] not in REDIRECT_STATUSES:
            return "conflicting_evidence", "The finding is not supported by a consistent redirect response."
        if fid == "redirect_detected":
            return "informational", "This finding describes the redirect response. Destination evidence is reported separately when available."
        if context["scheme"] != "https" or context["redirect_target_scheme"] != "http":
            return "conflicting_evidence", "An HTTPS-to-HTTP redirect is not supported by the URL and target scheme."
        return "needs_rule", "An HTTP redirect target was reported; the destination itself was not visited or assessed."
    raise AssertionError("Known finding has no handler.")


def _unrated(status, reason, perspective):
    if status == "needs_rule":
        reason += (" Visitor-specific scoring rules are pending." if perspective == "visitor" else
                   " Owner-specific scoring rules and asset/business impact context are pending.")
    return {
        "status": status,
        "reason": reason,
        "likelihood_factors": {"discoverability": None, "exploitability": None, "reproducibility": None},
        "likelihood": None,
        "cia": {"confidentiality": None, "integrity": None, "availability": None},
        "impact": None,
        "risk_score": None,
        "risk_level": None,
        "rule_id": None,
    }


def _assess_response(scan):
    """Read the initial response fields of one scanner report.

    Irrecoverable envelope errors raise ValueError. Recoverable field errors and
    contradictions are retained as validation issues and unscored findings.
    """
    url, parsed, checks, source_findings = _validate_input(scan)
    live = checks["live_response"]
    issues = []
    request_completed = _boolean(live, "request_completed", issues, "checks.live_response")
    cookies_detected = _boolean(live, "cookies_detected", issues, "checks.live_response")
    redirect_detected = _boolean(live, "redirect_detected", issues, "checks.live_response")
    tls_verified = _boolean(live, "tls_connection_verified", issues, "checks.live_response")
    supplied_https = _boolean(checks, "https_in_submitted_url", issues, "checks")
    if supplied_https is not None and supplied_https != (parsed.scheme == "https"):
        _issue(issues, "url_scheme_conflict", "checks.https_in_submitted_url",
               "The HTTPS check contradicts the submitted URL.", "error")
    failures = [f["id"] for f in source_findings if f["id"] in FAILURE_IDS]
    response_received = (False if request_completed is False or failures else
                         True if request_completed is True else None)
    if failures and request_completed is True:
        _issue(issues, "request_status_conflict", "checks.live_response.request_completed",
               "The request is marked completed but a request-failure finding is present.", "error")
    status_code = live.get("http_status_code")
    if status_code is not None and (type(status_code) is not int or not 100 <= status_code <= 599):
        _issue(issues, "invalid_http_status", "checks.live_response.http_status_code",
               "HTTP status must be an integer from 100 to 599 or null.", "error")
        status_code = None
    if response_received is True and status_code is None:
        _issue(issues, "http_status_missing", "checks.live_response.http_status_code",
               "The scanner reports a response but provides no usable HTTP status.")
    if response_received is False and status_code is not None:
        _issue(issues, "http_status_conflict", "checks.live_response.http_status_code",
               "An HTTP status exists despite an uncompleted or failed request.", "error")
    if tls_verified is True and (parsed.scheme != "https" or response_received is not True):
        _issue(issues, "tls_observation_conflict", "checks.live_response.tls_connection_verified",
               "TLS verification is inconsistent with the URL scheme or request outcome.", "error")
    raw_headers = live.get("security_headers", {})
    if not isinstance(raw_headers, dict):
        _issue(issues, "invalid_header_checks", "checks.live_response.security_headers",
               "Header check results must be an object.", "error")
        raw_headers = {}
    headers = {key: _boolean(raw_headers, key, issues, "checks.live_response.security_headers")
               for key in HEADER_CHECKS.values()}
    cookies = _cookie_details(live, cookies_detected, issues)
    target_scheme = _text(live.get("redirect_target_scheme"))
    if target_scheme is not None:
        target_scheme = target_scheme.lower()
    if redirect_detected is True and status_code not in REDIRECT_STATUSES:
        _issue(issues, "redirect_status_conflict", "checks.live_response.redirect_detected",
               "A redirect is reported without a matching redirect HTTP status.", "error")
    if "server_header_present" in live:
        _issue(issues, "unimplemented_scanner_flag_ignored", "checks.live_response.server_header_present",
               "This flag is excluded from the RAE evidence contract for compatibility with older scanner reports.")

    reported_skip = any(f["id"] in OFFLINE_IDS and _text(f.get("evidence")) is not None
                        for f in source_findings)
    offline_only = (reported_skip and request_completed is False and not failures
                    and status_code is None and tls_verified is None and redirect_detected is not True
                    and target_scheme is None and cookies_detected is not True and not cookies
                    and all(flag is None for flag in headers.values()))
    context = {
        "scheme": parsed.scheme, "response_received": response_received, "tls_verified": tls_verified,
        "offline_only": offline_only,
        "headers": headers, "cookies_detected": cookies_detected, "cookies": cookies,
        "redirect_detected": redirect_detected, "redirect_target_scheme": target_scheme,
        "http_status_code": status_code,
    }
    assessed = []
    for index, finding in enumerate(source_findings):
        status, reason = _finding_status(finding, context)
        evidence = _text(finding.get("evidence"))
        if finding.get("evidence") is not None and not isinstance(finding["evidence"], str):
            _issue(issues, "invalid_finding_evidence", f"findings[{index}].evidence",
                   "Textual evidence was expected; the supplied value cannot support scoring.", "error")
        if status == "conflicting_evidence":
            _issue(issues, "finding_check_conflict", f"findings[{index}]", reason, "error")
        limitations = []
        if _text(finding.get("limitation")):
            limitations.append(finding["limitation"])
        if finding["id"] in COOKIE_IDS:
            limitations.append("The scanner does not establish cookie purpose or reliably link each finding to structured cookie details.")
        if redirect_detected is True and finding["id"] in HEADER_CHECKS:
            limitations.append("This header observation describes the initial redirect response, not the destination page.")
        item = {
            "finding_ref": f"finding-{index + 1:04d}",
            "id": finding["id"],
            "category": _text(finding.get("category")),
            "evidence": evidence,
            "scanner_severity": _text(finding.get("severity")),
            "source": "scanner",
            "validation_status": status,
            "limitations": limitations,
            "perspectives": {p: _unrated(status, reason, p) for p in PERSPECTIVES},
        }
        reference = control_reference(finding["id"])
        if reference is not None:
            item["control_references"] = [reference]
        if finding["id"] == "threat_list_match":
            category = _text(finding.get("threat_category"))
            if category in THREAT_CATEGORIES:
                item["threat_category"] = category
        assessed.append(item)

    has_errors = any(i["severity"] == "error" for i in issues)
    if has_errors:
        scan_status = "inconsistent"
    elif offline_only:
        scan_status = "offline_only"
    elif response_received is False:
        scan_status = "failed"
    elif response_received is not True or status_code is None:
        scan_status = "incomplete"
    elif redirect_detected is True or not 200 <= status_code < 300 or (cookies_detected is True and not cookies):
        scan_status = "partial"
    else:
        scan_status = "completed_initial_response"

    preliminary = scan.get("preliminary_assessment")
    preliminary = preliminary if isinstance(preliminary, dict) else {}
    try:
        canonical = json.dumps(scan, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("Scanner result must contain valid JSON values.") from exc
    return {
        "engine_version": ENGINE_VERSION,
        "assessment_contract": "draft_for_team_review",
        "input_sha256": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
        "scan": {
            "url": url,
            "status": scan_status,
            "scope": "submitted_url_offline_only" if offline_only else "submitted_url_and_initial_response_only",
            "http_response_received": response_received,
            "http_status_code": status_code,
            "tls_connection_verified": tls_verified,
            "redirect_detected": redirect_detected,
            "redirect_target_scheme": target_scheme,
            "destination_assessed": False,
            "cookies_detected": cookies_detected,
            "cookies": cookies,
            "security_headers": headers,
        },
        "findings": assessed,
        "validation_issues": issues,
        "limitations": [
            ("The scanner supplied offline observations for the submitted URL."
             if offline_only else "This is a surface-level assessment of the submitted URL and initial response only."),
            "Redirect destinations, authenticated pages and internal systems were not assessed.",
            "Each perspective is limited to the consequences supported by the scanner evidence.",
            "An HTTPS connection or missing header does not establish that a website is safe, malicious or exploitable.",
            "The highest supported score covers the findings with enough evidence to score.",
        ],
        "scanner_preliminary_assessment": {
            "source": "scanner", "used_for_scoring": False,
            "risk_level": _text(preliminary.get("risk_level")),
            "reason": _text(preliminary.get("reason")),
        },
    }


def _unavailable_overall(counts, scan_status):
    if scan_status == "inconsistent":
        status, reason = "invalid_evidence", "Scanner data contains invalid or conflicting evidence. No overall rating is available."
    elif scan_status == "offline_only" or counts["reputation_match"]:
        status, reason = "insufficient_evidence", "The offline observations do not establish a numerical risk rating."
    elif scan_status in {"failed", "incomplete"}:
        status, reason = "insufficient_evidence", "The HTTP assessment did not provide sufficient evidence for an overall rating."
    elif counts["needs_rule"] and counts["insufficient_evidence"]:
        status, reason = "insufficient_evidence", "Some findings lack required evidence. Other findings still need scoring rules."
    elif counts["needs_rule"]:
        status, reason = "needs_rules", "One or more findings need a scoring rule for the available evidence."
    elif counts["incomplete"] or counts["insufficient_evidence"]:
        status, reason = "insufficient_evidence", "Available findings lack the evidence needed for an overall rating."
    elif counts["unsupported"]:
        status, reason = "unsupported_findings", "Some finding IDs have no reviewed handler; no overall rating is available."
    else:
        status, reason = "not_assessed", "No risk scenarios were scored. An empty findings list or passed controls do not establish website safety."
    return {"status": status, "risk_score": None, "risk_level": None, "reason": reason}


def _summarize(findings, scan_status, framework):
    summaries = {}
    for p in PERSPECTIVES:
        results = [(f, f["perspectives"][p]) for f in findings]
        counts = dict.fromkeys(("informational", "reputation_match", "needs_rule", "incomplete",
                                "insufficient_evidence", "conflicting_evidence", "unsupported"), 0)
        for _, rating in results:
            counts[rating["status"]] = counts.get(rating["status"], 0) + 1
        scored = [(f, rating) for f, rating in results if rating["risk_score"] is not None]
        unscored = [f["finding_ref"] for f, rating in results
                    if rating["risk_score"] is None and rating["status"] != "informational"]
        overall = _unavailable_overall(counts, scan_status)
        if scored and scan_status != "inconsistent":
            precedence = SEVERITY_ORDER[framework]
            finding, rating = max(scored, key=lambda pair: (
                pair[1]["risk_score"], precedence.index(pair[1]["risk_level"])
            ))
            overall = {
                "status": "highest_supported",
                "label": "Highest supported score",
                "risk_score": rating["risk_score"],
                "risk_level": rating["risk_level"],
                "reason": rating["reason"],
                "finding_ref": finding["finding_ref"],
                "rule_id": rating["rule_id"],
                "evidence": rating["evidence"],
                "rating_reasons": rating["rating_reasons"],
                "score_max": FRAMEWORKS[framework]["score_max"],
                "unscored_finding_refs": unscored,
            }
        summaries[p] = {
            "description": ("Potential harm to a person visiting or using the website." if p == "visitor" else
                            "Potential harm to the website owner's assets, data or operations."),
            "overall_risk": overall,
            "findings_received": len(findings),
            "findings_scored": len(scored),
            "status_counts": counts,
        }
    return summaries


def _read_redirect(chain, initial):
    """Validate the chain summary and assess its last recorded response independently."""
    if (not isinstance(chain, dict) or initial["http_response_received"] is not True
            or initial["http_status_code"] not in REDIRECT_STATUSES):
        raise ValueError("Redirect data requires a recorded initial redirect response.")
    status = chain.get("status")
    hops = chain.get("hops")
    count = chain.get("redirects_followed")
    completed = chain.get("destination_assessed")
    if (not isinstance(status, str) or status not in CHAIN_STATUSES
            or not isinstance(hops, list) or len(hops) > 4
            or type(count) is not int or not 0 <= count <= 3
            or len(hops) not in (count, count + 1)
            or type(completed) is not bool or completed != (status == "completed")):
        raise ValueError("The redirect status, hop count or completion flags are invalid.")

    def url_key(value):
        _, parsed = _validate_url(value)
        host = parsed.hostname.removesuffix(".").encode("idna").decode("ascii").lower()
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        return parsed.scheme, host, port, parsed.path or "/", parsed.query

    expected_source = url_key(initial["url"])
    checked_hops = []
    for index, hop in enumerate(hops):
        if not isinstance(hop, dict):
            raise ValueError("A redirect hop must be an object.")
        source, target = hop.get("from_url"), hop.get("to_url")
        source_key, target_key = url_key(source), url_key(target)
        code, followed = hop.get("http_status_code"), hop.get("followed")
        if (source_key != expected_source or type(code) is not int or code not in REDIRECT_STATUSES
                or (index == 0 and code != initial["http_status_code"])
                or followed is not (index < count)):
            raise ValueError("A redirect hop is inconsistent with the recorded chain.")
        checked_hops.append({"from_url": source, "to_url": target, "http_status_code": code,
                             "followed": followed})
        if followed:
            expected_source = target_key

    final_url = chain.get("final_url")
    raw_final = chain.get("final_result")
    offline_target = status == "threat_list_match"
    if offline_target and not checked_hops:
        raise ValueError("A redirect threat match requires a recorded redirect target.")
    if offline_target and len(hops) > count:
        expected_source = url_key(checked_hops[-1]["to_url"])
    if count or offline_target:
        if url_key(final_url) != expected_source or not isinstance(raw_final, dict):
            raise ValueError("The redirect destination and last followed hop disagree.")
        if url_key(raw_final.get("url")) != expected_source:
            raise ValueError("The destination report belongs to a different URL.")
        final = _assess_response(raw_final)
        final_scan = final["scan"]
        final_code = final_scan["http_status_code"]
        if completed and (len(hops) != count or final_scan["http_response_received"] is not True
                          or final_code is None or not 200 <= final_code < 300
                          or final_scan["redirect_detected"] is True):
            raise ValueError("The reported destination did not record a successful final response.")
        if status == "request_failed" and final_scan["http_response_received"] is not False:
            raise ValueError("The failed destination status conflicts with the recorded response.")
        if status == "http_error" and (final_scan["http_response_received"] is not True
                                      or final_code is None or 200 <= final_code < 300
                                      or final_code in REDIRECT_STATUSES):
            raise ValueError("The destination HTTP error conflicts with the recorded response.")
        if offline_target and (final_scan["status"] != "offline_only" or not any(
                f["validation_status"] == "reputation_match" for f in final["findings"])):
            raise ValueError("The redirect threat match requires an offline match on the recorded target.")
        if not offline_target and len(hops) > count and final_code != checked_hops[-1]["http_status_code"]:
            raise ValueError("The last response and the unfollowed hop disagree.")
    else:
        if status in {"completed", "request_failed", "http_error"} or final_url is not None or raw_final is not None:
            raise ValueError("A destination report requires a followed redirect.")
        final = None

    return {
        "status": status,
        "redirects_followed": count,
        "hops": checked_hops,
        "final_url": final_url,
        "reason": _text(chain.get("reason")),
        "destination_assessed": completed and final["scan"]["status"] != "inconsistent",
        "final_response": final["scan"] if final else None,
    }, final


def assess_scan(scan, *, framework="csa"):
    """Assess the submitted URL and any recorded redirect destination without network requests."""
    validate_framework(framework)
    result = _assess_response(scan)
    result["scoring_framework"] = {"id": framework, **FRAMEWORKS[framework]}
    initial = result["scan"]
    findings = result["findings"]
    issues = result["validation_issues"]
    checks = scan["checks"]
    if "redirect_assessment" in checks:
        try:
            chain, destination = _read_redirect(checks["redirect_assessment"], initial)
        except ValueError as exc:
            _issue(issues, "invalid_redirect_assessment", "checks.redirect_assessment", str(exc), "error")
        else:
            initial["scope"] = "submitted_url_and_recorded_redirect_chain"
            initial["redirect_assessment"] = chain
            result["limitations"][:2] = [
                "This assessment covers the initial HTTP response and the redirect evidence recorded by the scanner.",
                "Authenticated pages, response contents and internal systems are outside the assessment scope.",
            ]
            for finding in findings:
                finding.update(response_scope="initial_response", observed_url=initial["url"])
                finding["limitations"].append("This finding describes the submitted URL or its initial response.")
            if destination:
                final_scan = destination["scan"]
                for issue in destination["validation_issues"]:
                    issues.append({**issue, "path": "checks.redirect_assessment.final_result." + issue["path"]})
                for finding in destination["findings"]:
                    finding.update(finding_ref=f"finding-{len(findings) + 1:04d}",
                                   response_scope="redirect_destination", observed_url=final_scan["url"])
                    finding["limitations"].append(
                        "This finding describes the recorded redirect target."
                        if final_scan["status"] == "offline_only"
                        else "This finding describes the last redirect response inspected by the scanner."
                    )
                    findings.append(finding)
            if not any(issue["severity"] == "error" for issue in issues):
                initial["destination_assessed"] = chain["destination_assessed"]
                if chain["destination_assessed"]:
                    initial["status"] = (
                        "completed_redirect_destination"
                        if destination["scan"]["status"] == "completed_initial_response" else "partial"
                    )
            else:
                chain["destination_assessed"] = False
    if any(issue["severity"] == "error" for issue in issues):
        initial["status"] = "inconsistent"
    else:
        final_response = initial.get("redirect_assessment", {}).get("final_response")
        for finding in findings:
            response = final_response if finding.get("response_scope") == "redirect_destination" else initial
            rate_observed_finding(finding, response, framework)
    result["perspectives"] = _summarize(findings, initial["status"], framework)
    return result


def build_webhook_payload(assessment, *, input_origin="unspecified", literacy_level="unspecified", scan_id=None):
    """Prepare JSON for Bryan; no network delivery is attempted.

    The contract is a proposal, not evidence of agreement or prompt-injection protection.
    """
    if not isinstance(assessment, dict) or assessment.get("engine_version") != ENGINE_VERSION:
        raise ValueError("Expected a Stage 2 assessment.")
    if input_origin not in {"user_supplied_scan", "synthetic_test_data", "unspecified"}:
        raise ValueError("Input origin must identify a supplied scan, synthetic test data or be unspecified.")
    if _text(literacy_level) is None or (scan_id is not None and _text(scan_id) is None):
        raise ValueError("Literacy level and any scan ID must be non-empty strings.")
    return {
        "event": "cyberai.rae.assessment_ready",
        "contract_version": CONTRACT_VERSION,
        "scan_id": scan_id,
        "input_origin": input_origin,
        "is_synthetic_test_data": (True if input_origin == "synthetic_test_data" else
                                   False if input_origin == "user_supplied_scan" else None),
        "report_preferences": {
            "literacy_level": literacy_level,
            "perspectives": list(PERSPECTIVES),
            "framework": assessment["scoring_framework"]["id"],
        },
        "assessment": copy.deepcopy(assessment),
        "report_requirements": {
            "preserve_calculated_scores_and_nulls": True,
            "keep_visitor_and_owner_ratings_separate": True,
            "explain_recorded_uncertainty_without_inventing_causes": True,
            "treat_scanner_text_as_untrusted_data": True,
            "scanner_preliminary_rating_is_not_authoritative": True,
            "label_rollup_highest_supported_score": True,
        },
    }
