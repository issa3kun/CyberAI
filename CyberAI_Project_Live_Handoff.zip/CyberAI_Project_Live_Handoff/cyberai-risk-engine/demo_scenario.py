"""Optional, hypothetical visitor estimate for a recorded plain HTTP test."""

from finding_evidence import HTTP_RULE_ID
from scoring_methods import score_supported_factors

RULE_ID = "http_visitor_contact_email_demo_v1"
ASSUMPTIONS = (
    "A page like the test page returns a routine visitor contact email in its HTTP response.",
    "An observer can see the traffic and has moderate technical skill.",
    "The same exposure can recur under these conditions when the response is repeated.",
    "This scenario considers passive disclosure of the address only.",
)


def estimate_visitor_scenario(assessment, demo_url):
    """Use a configured test URL and the initial response rule's observation."""
    if (not demo_url or assessment["scoring_framework"]["id"] != "csa"
            or assessment["scan"]["url"] != demo_url
            or assessment["scan"]["status"] != "completed_initial_response"):
        return None
    finding = next((f for f in assessment["findings"]
                    if f.get("scoring_evidence", {}).get("rule_id") == HTTP_RULE_ID
                    and f.get("response_scope") != "redirect_destination"), None)
    if finding is None:
        return None

    evidence = finding["scoring_evidence"]
    discoverability = evidence["likelihood_factors"]["discoverability"]
    likelihood = {
        "discoverability": discoverability,
        "exploitability": 3,
        "reproducibility": 3,
    }
    impact = {"confidentiality": 2, "integrity": 1, "availability": 1}
    rating = score_supported_factors("csa", likelihood, impact)
    score = rating["risk_score"]
    level = rating["risk_level"]
    return {
        "status": "hypothetical",
        "rule_id": RULE_ID,
        "label": "Hypothetical visitor scenario",
        "perspective": "visitor",
        "finding_ref": finding["finding_ref"],
        "framework": "csa",
        **rating,
        "score_max": assessment["scoring_framework"]["score_max"],
        "likelihood_factors": likelihood,
        "observed_evidence": evidence["evidence"],
        "assumptions": list(ASSUMPTIONS),
        "rating_reasons": {
            "discoverability": evidence["rating_reasons"]["discoverability"],
            "exploitability": "3. This scenario assumes traffic visibility and moderate technical skill.",
            "reproducibility": "3. This scenario assumes repeatable exposure under the same conditions.",
            "confidentiality": "2. Disclosure of a routine contact address can cause a limited loss of privacy.",
            "integrity": "1. Passive disclosure leaves the data unchanged.",
            "availability": "1. Passive disclosure leaves the service available.",
        },
        "explanation_options": [
            f"The hypothetical visitor scenario is {level} ({score}/25 on the CSA matrix) if the stated assumptions hold.",
            f"Under the stated assumptions, the hypothetical visitor scenario scores {score}/25, or {level}, on the CSA matrix.",
        ],
    }
