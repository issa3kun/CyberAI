"""CSA 5×5 calculation for scenarios with supported factor ratings."""

# CSA's February 2021 guide, printed page 16, Figure 5.
# These are exactly the products attainable from integer factors 1 through 5.
RISK_LEVELS = {
    1: "Low", 2: "Low", 3: "Low", 4: "Low",
    5: "Medium", 6: "Medium", 8: "Medium", 9: "Medium",
    10: "Medium High", 12: "Medium High",
    15: "High", 16: "High", 20: "Very High", 25: "Very High",
}


def _validate_rating(value, name):
    """Accept integer ratings 1-5, rejecting booleans and missing values."""
    if type(value) is not int or not 1 <= value <= 5:
        raise ValueError(f"{name} must be an integer from 1 to 5.")


def calculate_likelihood(discoverability, exploitability, reproducibility):
    """Round the mean of three already-justified ratings, as CSA proposes.

    This function does not decide the three ratings from scanner findings.
    Integer thirds cannot produce an exact .5 rounding tie.
    """
    factors = {
        "discoverability": discoverability,
        "exploitability": exploitability,
        "reproducibility": reproducibility,
    }
    for name, value in factors.items():
        _validate_rating(value, name)
    return round(sum(factors.values()) / 3)


def calculate_risk(likelihood, confidentiality, integrity, availability):
    """Calculate a single scenario using already-justified ratings.

    CIA maximum is the impact. This is a ranking index, not a probability.
    Unknown inputs must remain unassessed instead of being replaced by 1.
    """
    cia = {
        "confidentiality": confidentiality,
        "integrity": integrity,
        "availability": availability,
    }
    _validate_rating(likelihood, "likelihood")
    for name, value in cia.items():
        _validate_rating(value, name)
    impact = max(cia.values())
    score = likelihood * impact
    return {
        "likelihood": likelihood,
        "cia": cia,
        "impact": impact,
        "risk_score": score,
        "risk_level": RISK_LEVELS[score],
    }
