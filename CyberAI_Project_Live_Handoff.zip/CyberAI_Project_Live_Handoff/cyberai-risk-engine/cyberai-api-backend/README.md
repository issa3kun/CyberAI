# CyberAI Flask Scanner — AdaBoost + SHAP integrated pilot

This package keeps your existing scanner, Scan IDs, offline known-malware lookup,
custom-port URL acceptance and scanner-to-n8n handoff. It adds a benign/phishing
AdaBoost prediction with SHAP explanation under the new top-level `url_model` key.

Start with [RAE 0.4.0 setup, field definitions and verification](RAE_040_INTEGRATION.md). The model evaluation is in [the AdaBoost guide](ADABOOST_SHAP_INTEGRATION_GUIDE.md).

> **Scan ID + OpenRouter:** See `SCAN_ID_AND_OPENROUTER_GUIDE.md` for the added `scan_id` field, n8n ID propagation, and the optional `test_openrouter.py` script.

# CyberAI API Backend

This package contains Ziyad's surface-level scanner and the scanner intake sender supplied by Imran. The project folder is named `cyberai_api_backend`.

## Start on Windows

Extract the ZIP. In VS Code, open the inner folder named `cyberai_api_backend` containing `app.py` and `requirements.txt`. Open a terminal in that folder and run these commands.

```powershell
pymanager exec -V:3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install -r requirements-ml.txt
.\.venv312\Scripts\python.exe app.py
```

The startup message prints the exact `app.py` path. Flask listens on `http://127.0.0.1:5000`. Keep this terminal open while testing. Create the virtual environment locally when you extract this source package.

## Check with Postman

Use `GET http://127.0.0.1:5000/api/health` to confirm that Flask is running.

For a scan, use `POST http://127.0.0.1:5000/api/scan`. Select Body, raw, JSON and send the following body.

```json
{"url": "www.trip.com"}
```

The backend adds `https://` to an input without a scheme before applying URL validation. Complete HTTP, HTTPS, FTP and SFTP URLs keep their specified scheme.

HTTP/HTTPS URLs with custom ports are accepted for offline URL analysis and malware-dataset matching. To perform **live HTTP inspection** on a custom port, explicitly enable that port in the PowerShell terminal before starting Flask. Separate multiple approved ports with commas. Port 80 for HTTP and 443 for HTTPS work by default.

```powershell
$env:CYBERAI_ALLOWED_HTTP_PORTS = "35855"
.\.venv312\Scripts\python.exe app.py
```

The scanner inspects the status and headers without reading or executing the response body. For live inspection, a custom port must be explicitly enabled for both submitted URLs and redirect destinations; unapproved ports are handled without a live HTTP connection.

## Scanner JSON and redirect evidence

The default HTTP/HTTPS response has the existing top-level fields `url`, `checks`, `findings`, `preliminary_assessment`, `success`, `scan_type` and `status`. The original `checks.live_response` describes the initial response. Cookie records contain names and security attributes.

For redirects, `checks.redirect_assessment` records the chain, completion status, final URL and `final_result`. The destination's `final_result` uses the existing scanner report structure. Up to three redirects are followed after destination validation. Loops, non-public addresses, embedded credentials, unsupported protocols, custom ports that have not been enabled and HTTPS-to-HTTP downgrades stop the chain.

When the destination is successfully inspected, the top-level preliminary summary reflects its observations. Stronger transport findings from completed responses are retained. If the chain is incomplete, the summary explains the missing assessment. An observed certificate verification failure produces `tls_verification_failed` and a preliminary High transport rating. A generic TLS-handshake failure records unavailable verification and `connection_error`. Website reputation requires separate evidence.

In the supplied Trip.com capture, the initial response is HTTP 302 and the destination response is HTTP 200 with a preliminary Low rating. The top-level summary therefore reports Low after these fixes. A new live scan can have a different result.

The optional `POST /api/scan?details=1` adds the existing DNS and accessibility fields. Successful redirect destinations supply the accessibility summary.

For compatibility, `success: true` and `status: "URL validated"` in the default response indicate that validation passed. Read `checks.live_response.request_completed` for the initial network outcome and `checks.redirect_assessment` for destination outcomes. A scan that records a network timeout still returns its evidence to the caller.

## Reviewed URL threat list

Create a JSON file that maps exact URLs to reviewed categories (`phishing`, `malware`, or `unwanted_software`). Set `CYBERAI_THREAT_LIST_FILE` to its path before starting Flask. This setting is optional and the list is maintained locally.

For a synthetic test, save `{"https://example.com/cyberai-test": "phishing"}` to `threats.json` beside `app.py` and run:

```powershell
$env:CYBERAI_THREAT_LIST_FILE = "$PWD\threats.json"
.\.venv312\Scripts\python.exe app.py
```

Submit `https://example.com/cyberai-test`. A match adds `threat_list_match`, sets preliminary risk to High, and skips the HTTP request for the matched URL. A match on a checked redirect destination appears in `checks.redirect_assessment.final_result.findings` and is reflected in the top-level preliminary rating. Remove the synthetic entry after testing.

## Imran's RAE and n8n intake

The root files `send_scan.py`, `scan_message.py` and `n8n_client.py` are Imran's supplied sender. Automatic forwarding calls `send_scan_result` with `input_origin="user_supplied_scan"`. The full response object sent to Postman becomes `scan_result` in the existing `cyberai.scanner.intake/0.1.0-draft` envelope.

For the local test, run Flask, n8n and the RAE on the same laptop. In the same PowerShell terminal used to start Flask, configure the published intake URL first.

```powershell
$env:CYBERAI_N8N_SCAN_WEBHOOK_URL = "http://localhost:5678/webhook/cyberai-scanner-intake"
Remove-Item Env:CYBERAI_N8N_HEADER_NAME, Env:CYBERAI_N8N_HEADER_VALUE -ErrorAction SilentlyContinue
.\.venv312\Scripts\python.exe app.py
```

The local intake is configured with Authentication set to None. The sender also supports Header Auth through `CYBERAI_N8N_HEADER_NAME` and `CYBERAI_N8N_HEADER_VALUE` when that is configured in n8n.

Forwarding runs for valid HTTP/HTTPS scan reports, including reports with a website timeout. Delivery uses a ten-second network timeout. Connection, HTTP or response-format failures produce a warning in the Flask terminal while the scanner JSON is returned to Postman. The sender makes one attempt. Check n8n's execution history after a delivery timeout before resubmitting.

Leave the webhook URL unset to test the scanner on its own. Domain-only requests and FTP/SFTP results use their own evidence formats.

RAE 0.4.0 reads the full scanner result and validates the initial response, redirect chain and recorded destination. Send the original result to preserve all three. Optional `framework` in the scan request or sender CLI selects CSA or OWASP. CSA is the default.

## Domain and transfer checks

`POST /api/domain-check` accepts a JSON body such as `{"target": "example.com"}`. It reports hostname resolution and the public-address policy.

FTP checks a bounded greeting on port 21. SFTP checks an SSH handshake on port 22. File paths, authentication, SFTP subsystem availability and SSH host-key trust require further evidence.

## TOR status

This package implements the scanner/backend portion of the TOR with surface HTTP, TLS, cookie and address checks, controlled redirects and the n8n intake handoff. The default JSON contract is suitable for the supplied RAE adapter and sender.

The bundled AdaBoost and SHAP pilot provides URL-text evidence. Imran owns the risk factors, numerical scoring and aggregation. Bryan owns the Qwen report and its validator. Deployment, UI, storage, access control and rate limiting are separate platform tasks.

The HTTP scanner reads externally visible response settings. The intake retains the scanner observations and classifier output for the team.
