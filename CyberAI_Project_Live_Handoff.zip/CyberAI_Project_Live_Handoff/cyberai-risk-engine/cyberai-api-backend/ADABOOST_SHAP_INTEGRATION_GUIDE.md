# CyberAI: integrating the uploaded CyberAI_999 AdaBoost and SHAP pilot

## What was added

- `ml/url_features.py` — eight URL features from your trained pilot. Accepts custom ports for offline classification, but **the model was not trained with custom ports**. They are not included among the eight model features.
- `models/adaboost_uci999.joblib` — your actual trained AdaBoost (benign versus phishing) model, copied from the ZIP you uploaded.
- `models/pilot_metrics.json` — original held-out evaluation from the uploaded ZIP.
- `models/shap_background.json` — 16 deterministic training-split reference feature rows (no URLs), used to calculate new SHAP explanations.
- `url_model.py` — runs the model and computes SHAP explanations offline for each HTTP/HTTPS URL.
- `app.py` — one additional call to `predict_ml_url(url)` in the HTTP/HTTPS branch; adds `url_model` to the **original** scanner JSON and n8n payload.
- `tests/test_model_integration.py` — verifies additive JSON and matching n8n Scan IDs with mocked requests.
- `scanner/url_checks.py` — reports the RAE 0.4.0 three-valued TLS result and attributes evidence to individual responses.

No retraining is performed during an API request. `clean_urls.csv` remains an **exact-match malware list**, separate from the phishing classifier. We did **not** merge the classifier's prediction into the scanner's `preliminary_assessment`; that requires validation and agreement with Imran on scoring rules.

## VS Code / Windows PowerShell (Python 3.12)

Extract this ZIP to a **new** folder so you have a backup of your existing backend. Open the `cyberai_api_backend` folder in VS Code.

```powershell
py -3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install -r requirements-ml.txt
.\.venv312\Scripts\python.exe test_url_model.py "https://www.example.com/"
.\.venv312\Scripts\python.exe test_url_model.py "http://example.com:38478/i"
.\.venv312\Scripts\python.exe -m unittest discover -s tests -v
.\.venv312\Scripts\python.exe app.py
```

If you already have `.venv312`, reuse it. If `py -3.12` is unavailable, use the Python 3.12 launcher command installed on your machine, such as `pymanager exec -V:3.12 -m venv .venv312`.

In Postman: POST `http://127.0.0.1:5000/api/scan` with `{"url":"https://example.com/"}`. Look for top-level `scan_id`, `url_model`, `checks`, `findings` and `preliminary_assessment`. In n8n, `body.scan_result.url_model` will appear along with `body.scan_result.scan_id`; the envelope's `body.scan_id` should match. Configure `CYBERAI_N8N_SCAN_WEBHOOK_URL` as in the earlier guide, if Imran's workflow is active.

## Toggle SHAP

SHAP is enabled by default. To temporarily skip potentially slow explanations, in the VS Code PowerShell terminal *before starting Flask* run:

```powershell
$env:CYBERAI_ENABLE_SHAP = "0"
```

AdaBoost predictions will still run and `explanation_status` will be `disabled`. To re-enable: `$env:CYBERAI_ENABLE_SHAP = "1"`, restart Flask.

## How to interpret output

- `url_model.prediction`: `benign` or `phishing` — a **machine-learning prediction**, not a verdict.
- `url_model.phishing_model_score`: uncalibrated score for the phishing class. `url_model.score_type` records this in the JSON.
- `url_model.top_factors`: SHAP factors (positive increases the **phishing** model score; negative decreases it). The values explain a model, not independently proven risk factors.
- `url_model.status`: `available` if classification ran; `unavailable` means you can still use the scanner without ML.
- `preliminary_assessment.risk_level`: unchanged Low/Medium/High/Not enough information, computed from actual scanner findings and known URL reputation. Imran's RAE calculates final risk separately.
- `tls_connection_verified` is true after verified HTTPS, false for a recorded certificate verification failure, and null for HTTP, skipped requests or unavailable verification. `checks.live_observation.reason_code` distinguishes timeout, generic handshake failure and certificate verification failure.

## Accuracy limitation (important for your TOR)

The uploaded model is a 999-case demo with only 533 training rows and 133 test rows. It detected 26 of 67 held-out phishing URLs; it missed 41 and has 65.4% accuracy. This is **not sufficient to claim robust phishing detection** or give an automatic High rating based solely on the prediction. The model was trained on phishing, not URLhaus malware, and its custom-port predictions are out of the training distribution. Later, train and independently validate a larger, representative model.

Never visit or fetch URLhaus malware links to test the classifier; both AdaBoost and SHAP work entirely from the URL text. Deploy your Flask server with rate limits, blocking of internal/private addresses, and allowlisted live ports.

`joblib` model artifacts can execute code when loaded; use only a model you trained or reviewed yourself. Keep your trusted model file out of user-controlled upload directories.
