"""Surface-level HTTP checks with validated redirect destination inspection."""

from collections import ChainMap
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import io
from http.client import HTTPConnection, HTTPSConnection, HTTPException
from urllib.parse import quote, urljoin, urlparse, urlsplit, urlunsplit
from http.cookies import SimpleCookie, CookieError
import ipaddress
import csv
from functools import lru_cache
import json
import logging
import os
import re
import socket
import ssl
from pathlib import Path

from scanner.domain_checks import DomainLookupError, UnsafeTargetError, resolve_public_addresses

MAX_REDIRECTS = 3
REDIRECT_STATUSES = {301, 302, 303, 307, 308}
HTTP_DEFAULT_PORTS = {"http": 80, "https": 443}
HEADER_CHECKS = {
    "content_security_policy": ("Content-Security-Policy",),
    "x_content_type_options": ("X-Content-Type-Options",),
    "strict_transport_security": ("Strict-Transport-Security",),
    "frame_protection": ("X-Frame-Options", "Content-Security-Policy"),
}
HEADER_FINDINGS = {
    "missing_csp": "content_security_policy",
    "weak_x_content_type_options": "x_content_type_options",
    "missing_or_weak_hsts": "strict_transport_security",
    "missing_frame_protection": "frame_protection",
}
logger = logging.getLogger(__name__)


def http_scan_port(parsed):
    """Use the scheme default or a custom port enabled by the scanner operator."""
    default_port = HTTP_DEFAULT_PORTS[parsed.scheme]
    port = parsed.port
    if port is None or port == default_port:
        return default_port
    if port == 0:
        raise ValueError("Please provide a port between 1 and 65535.")
    configured_ports = os.environ.get("CYBERAI_ALLOWED_HTTP_PORTS", "").split(",")
    if not any(entry.strip() == str(port) for entry in configured_ports):
        raise ValueError(f"HTTP/HTTPS scanning on port {port} is not enabled.")
    return port


def _normalise_http_url(url, *, enforce_port_policy=True):
    """Validate a target before requesting it and remove its fragment."""
    if (
        not isinstance(url, str)
        or not url
        or len(url) > 2048
        or "\\" in url
        or any(char.isspace() or ord(char) < 32 or ord(char) == 127 for char in url)
    ):
        raise ValueError("The target URL contains invalid characters or is too long.")
    parsed = urlsplit(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Redirects must use a complete HTTP or HTTPS URL.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("URLs containing login credentials are blocked.")
    port = http_scan_port(parsed) if enforce_port_policy else parsed.port
    if port == 0:
        raise ValueError("Please provide a port between 1 and 65535.")
    if not re.fullmatch(r"(?:\[[^\]]+\]|[^:\[\]]+)(?::[0-9]+)?", parsed.netloc):
        raise ValueError("The target hostname or port is invalid.")
    hostname = parsed.hostname.removesuffix(".")
    if "%" in hostname:
        raise ValueError("Encoded or scoped hostnames are blocked.")
    try:
        literal = ipaddress.ip_address(hostname)
    except ValueError:
        hostname = hostname.encode("idna").decode("ascii").lower()
        label = r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
        if len(hostname) > 253 or not all(
            re.fullmatch(label, part) for part in hostname.split(".")
        ):
            raise ValueError("The target hostname is invalid.")
    else:
        hostname = f"[{literal.compressed}]" if literal.version == 6 else str(literal)
    authority = hostname
    if port is not None and port != HTTP_DEFAULT_PORTS[parsed.scheme]:
        authority = f"{hostname}:{port}"
    return urlunsplit((parsed.scheme, authority, parsed.path or "/", parsed.query, ""))


def _live_http_port_allowed(parsed):
    """Custom ports are valid URL data, not automatically live-scan targets."""
    port = parsed.port
    default = HTTP_DEFAULT_PORTS[parsed.scheme]
    if port is None or port == default:
        return True
    allowed = os.environ.get("CYBERAI_ALLOWED_HTTP_PORTS", "").split(",")
    return str(port) in {item.strip() for item in allowed}


THREAT_CATEGORIES = {"malware", "phishing", "unwanted_software"}


class _ThreatIndex(dict):
    """A URL-to-category mapping usable by the batch scripts, with local source metadata."""

    def __init__(self, filename, kind):
        super().__init__()
        self.metadata = {
            "lookup_source": Path(filename).name if filename else None,
            "source_type": kind, "status": "available",
            "dataset_version": None, "dataset_timestamp": None,
        }


def _parse_csv_index(src, index, strict):
    rows = csv.DictReader(src, strict=True)
    fields = rows.fieldnames or []
    if not {"url", "label"}.issubset(fields) or len(set(fields)) != len(fields):
        raise ValueError("expected unique column names including url and label")
    for row in rows:
        try:
            if None in row or None in row.values():
                raise ValueError("incorrect column count")
            category = row["label"].strip().lower()
            if category not in THREAT_CATEGORIES and category != "benign":
                raise ValueError("unknown or empty label")
            key = _normalise_http_url(row["url"], enforce_port_policy=False)
            if category in THREAT_CATEGORIES:
                index[key] = category
        except ValueError as exc:
            if strict:
                raise ValueError(f"row {rows.line_num}: {exc}") from exc
            index.metadata["status"] = "partial"


def _parse_json_index(src, index):
    entries = json.load(src)
    if not isinstance(entries, dict):
        raise ValueError("expected a JSON object mapping URLs to threat categories")
    for url, category in entries.items():
        if not isinstance(category, str) or category not in THREAT_CATEGORIES:
            raise ValueError("unknown threat category")
        index[_normalise_http_url(url, enforce_port_policy=False)] = category


def _read_index(path, kind, *, strict=False):
    index = _ThreatIndex(path, kind)
    try:
        if not path:
            raise ValueError("no dataset path supplied")
        with Path(path).open("rb") as binary:
            index.metadata["dataset_version"] = "sha256:" + hashlib.file_digest(binary, "sha256").hexdigest()
            index.metadata["dataset_timestamp"] = datetime.fromtimestamp(
                os.fstat(binary.fileno()).st_mtime, timezone.utc
            ).isoformat()
            binary.seek(0)
            with io.TextIOWrapper(binary, encoding="utf-8-sig", newline="") as src:
                if kind == "csv":
                    _parse_csv_index(src, index, strict)
                else:
                    _parse_json_index(src, index)
    except (OSError, ValueError, csv.Error) as exc:
        if strict and isinstance(exc, OSError):
            raise
        if strict and isinstance(exc, csv.Error):
            raise csv.Error(f"Invalid CSV {str(path)!r}: {exc}") from exc
        if strict:
            raise ValueError(f"Cannot load threat {kind.upper()} {str(path)!r}: {exc}") from exc
        logger.warning("Could not fully load local threat %s %s: %s", kind, index.metadata["lookup_source"], exc)
        index.metadata["status"] = "partial" if index else "unavailable"
    return index


def load_csv_threats(path, *, strict=False):
    """Load a local cleaned url,label CSV. Strict mode rejects malformed datasets."""
    return _read_index(path, "csv", strict=strict)


@lru_cache(maxsize=4)
def _cached_index(path, kind, file_signature):
    # The signature in the cache key makes in-place updates and replacements visible.
    return _read_index(path, kind)


def _configured_index(path, kind):
    try:
        stat = Path(path).stat()
    except OSError:
        return _read_index(path, kind)
    return _cached_index(str(path), kind, (stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns))


def _load_threat_list():
    csv_path = os.environ.get("CYBERAI_URL_DATASET_FILE", "").strip()
    csv_path = csv_path or Path(__file__).resolve().parent.parent / "clean_urls.csv"
    csv_index = _configured_index(csv_path, "csv")
    json_path = os.environ.get("CYBERAI_THREAT_LIST_FILE", "").strip()
    if json_path:
        return ChainMap(_configured_index(json_path, "json"), csv_index)
    return csv_index


def _reputation(url, threats):
    key = _normalise_http_url(url, enforce_port_policy=False)
    sources = threats.maps if isinstance(threats, ChainMap) else [threats]
    records = []
    match = None
    for source in sources:
        metadata = getattr(source, "metadata", {
            "lookup_source": None, "source_type": "supplied_mapping",
            "status": "unavailable" if source is None else "available",
            "dataset_version": None, "dataset_timestamp": None,
        })
        records.append(dict(metadata))
        if match is None and source is not None and key in source:
            match = (source[key], metadata)

    states = {record["status"] for record in records}
    if match is not None:
        status = "match"
    elif states == {"available"}:
        status = "no_match"
    elif states == {"unavailable"}:
        status = "unavailable"
    else:
        status = "partial"
    category, origin = match or (None, {})
    return {
        "status": status, "threat_category": category, "lookup_time": datetime.now(timezone.utc).isoformat(),
        "lookup_source": origin.get("lookup_source"), "dataset_version": origin.get("dataset_version"),
        "dataset_timestamp": origin.get("dataset_timestamp"), "sources": records,
    }


def _request_path(parsed):
    path = urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    return quote(path, safe="/%?:@!$&'()*+,;=-._~[]")


@contextmanager
def _open_public_response(url, addresses):
    """Send one GET to a validated public IP, preserving the hostname for TLS.
    Pinning the socket to the checked IP avoids a second, unvalidated DNS lookup
    between URL validation and the network connection (DNS rebinding).
    """
    parsed = urlsplit(_normalise_http_url(url))
    hostname = parsed.hostname
    if parsed.scheme not in ("http", "https") or not hostname:
        raise UnsafeTargetError("Only HTTP/HTTPS URLs with a hostname are supported.")
    port = http_scan_port(parsed)
    hostname = hostname.removesuffix(".").encode("idna").decode("ascii")
    ips = addresses if addresses is not None else resolve_public_addresses(hostname, port)
    target = _request_path(parsed)
    last_error = None
    connection = None
    response = None
    for ip in ips[:3]:  # Limit the number of connection attempts.
        connection = None
        try:
            if parsed.scheme == "https":
                connection = HTTPSConnection(
                    hostname, port=port, timeout=5,
                    context=ssl.create_default_context(),
                )
            else:
                connection = HTTPConnection(hostname, port=port, timeout=5)
            # HTTPConnection / HTTPSConnection uses _create_connection when
            # opening a socket. Replace it for this request with a pinned IP.
            # HTTPS still sends the original hostname as SNI and verifies its
            # certificate against that hostname.
            def connect_to_checked_ip(address, timeout, source_address=None, *, checked_ip=ip):
                return socket.create_connection(
                    (checked_ip, port), timeout=timeout, source_address=source_address
                )
            connection._create_connection = connect_to_checked_ip
            connection.request("GET", target, headers={
                "User-Agent": "CyberAI-Academic-Scanner/0.1",
                "Connection": "close",
            })
            response = connection.getresponse()
            break
        except (OSError, HTTPException) as exc:
            last_error = exc
            if connection is not None:
                connection.close()
            connection = None
    if response is None or connection is None:
        if last_error is not None:
            raise last_error
        raise UnsafeTargetError("No connection attempt could be made.")
    try:
        yield response
    finally:
        try:
            response.close()
        except OSError:
            logger.debug("HTTP response cleanup failed", exc_info=True)
        finally:
            try:
                connection.close()
            except OSError:
                logger.debug("HTTP connection cleanup failed", exc_info=True)


def inspect_url(url, *, addresses=None, force_offline=False):
    """Inspect the initial response and up to three validated redirects."""
    threats = _load_threat_list()
    redirect_targets = []
    result = _inspect_single_url(
        url, addresses=addresses, redirect_targets=redirect_targets, threats=threats,
        force_offline=force_offline,
    )
    if result["checks"]["live_response"]["http_status_code"] in REDIRECT_STATUSES:
        initial_assessment = dict(result["preliminary_assessment"])
        redirect = _inspect_redirects(result, redirect_targets, threats)
        result["checks"]["redirect_assessment"] = redirect
        final_result = redirect.get("final_result") or {}
        final_assessment = final_result.get("preliminary_assessment", {})
        if redirect["destination_assessed"]:
            summary = dict(final_assessment)
            scope = f"Redirect destination assessed at {redirect['final_url']}. "
        else:
            summary = {"risk_level": "Not enough information", "reason": ""}
            scope = f"Redirect assessment incomplete. {redirect['reason']} "
        # Preserve stronger findings from the original URL or destination.
        priority = {"High": 2, "Medium": 1}
        for observation in (initial_assessment, final_assessment):
            if priority.get(observation.get("risk_level"), 0) > priority.get(
                summary.get("risk_level"), 0
            ):
                summary = dict(observation)
        summary["reason"] = scope + summary["reason"]
        result["preliminary_assessment"] = summary
    return result


def inspect_url_offline(url, *, threats):
    """Use only the supplied local lookup. The batch contract has no model or DNS dependency."""
    return _inspect_single_url(url, threats=threats, offline_reason="offline_batch")


def _inspect_redirects(initial_result, redirect_targets, threats):
    """Keep every destination's evidence separate from the initial response."""
    current = initial_result
    current_url = _normalise_http_url(initial_result["url"])
    visited = {current_url}
    assessment = {
        "status": "incomplete",
        "max_redirects": MAX_REDIRECTS,
        "redirects_followed": 0,
        "hops": [],
        "final_url": None,
        "destination_assessed": False,
        "final_result": None,
        "reason": "",
    }
    while True:
        live = current["checks"]["live_response"]
        if any(finding["id"] == "threat_list_match" for finding in current["findings"]):
            assessment.update(
                status="threat_list_match",
                reason_code="threat_list_match",
                reason="The redirect destination matched the reviewed threat list.",
            )
            return assessment
        if not live["request_completed"]:
            assessment.update(
                status="request_failed",
                reason_code=current["checks"]["live_observation"]["reason_code"],
                reason="A destination request failed. See final_result.findings.",
            )
            return assessment
        status_code = live["http_status_code"]
        if status_code not in REDIRECT_STATUSES:
            assessed = status_code is not None and 200 <= status_code < 300
            assessment.update(
                status="completed" if assessed else "http_error",
                destination_assessed=assessed,
                reason=(
                    "The destination's response, TLS and cookie settings were inspected. "
                    "Its preliminary rating covers these surface checks only."
                    if assessed else "The destination returned a non-success HTTP status."
                ),
            )
            return assessment
        if not redirect_targets:
            assessment.update(
                status="invalid_redirect",
                reason_code="missing_location",
                reason="The redirect has no usable Location header.",
            )
            return assessment
        location = redirect_targets[0]
        try:
            # Check the raw value before urljoin can strip control characters.
            if len(location) > 2048 or "\\" in location or any(
                char.isspace() or ord(char) < 32 or ord(char) == 127
                for char in location
            ):
                raise ValueError("The redirect Location contains invalid characters.")
            target = _normalise_http_url(urljoin(current_url, location), enforce_port_policy=False)
        except ValueError:
            assessment.update(
                status="blocked",
                reason_code="invalid_redirect_target",
                reason="The redirect URL is malformed, uses credentials, or violates the URL policy.",
            )
            return assessment
        hop = {
            "from_url": current_url,
            "http_status_code": live["http_status_code"],
            "to_url": target,
            "followed": False,
            "source_response_ref": current["checks"]["live_observation"]["response_ref"],
        }
        assessment["hops"].append(hop)
        hop_index = len(assessment["hops"])
        parsed = urlsplit(target)
        if not _live_http_port_allowed(parsed):
            stop = ("blocked", "unapproved_port", "The redirect port is not approved for live inspection.")
        elif urlsplit(current_url).scheme == "https" and parsed.scheme == "http":
            stop = (
                "blocked", "https_downgrade",
                "An HTTPS-to-HTTP redirect would remove transport encryption.",
            )
        elif target in visited:
            stop = ("loop_detected", "redirect_loop", "The redirect chain repeats a URL.")
        elif assessment["redirects_followed"] >= MAX_REDIRECTS:
            stop = ("limit_reached", "redirect_limit", "The three-redirect limit was reached.")
        else:
            stop = None
            try:
                target_addresses = resolve_public_addresses(parsed.hostname, http_scan_port(parsed))
            except (DomainLookupError, OSError):
                stop = ("blocked", "dns_failure", "DNS did not provide usable destination addresses.")
            except (UnsafeTargetError, ValueError):
                stop = (
                    "blocked", "address_policy",
                    "The redirect destination could not be resolved to permitted public addresses.",
                )
        if stop:
            status, reason_code, reason = stop
            hop["destination_observation"] = _live_observation(
                target, hop_index, {}, {}, skip_reason=reason_code,
            )
            assessment.update(status=status, reason_code=reason_code, reason=reason)
            return assessment
        # Pass the checked numeric addresses directly to the existing HTTP client.
        redirect_targets = []
        current = _inspect_single_url(
            target, addresses=target_addresses, redirect_targets=redirect_targets, threats=threats,
            hop_index=hop_index,
        )
        hop["destination_observation"] = current["checks"]["live_observation"]
        hop["destination_findings"] = current["findings"]
        hop["destination_reputation"] = current["checks"]["reputation"]
        visited.add(target)
        current_url = target
        hop["followed"] = current["checks"]["live_observation"]["state"] != "skipped"
        if hop["followed"]:
            assessment["redirects_followed"] += 1
        assessment["final_url"] = target
        assessment["final_result"] = current


def _inspect_single_url(
    url, *, addresses=None, redirect_targets=None, threats=None, force_offline=False, offline_reason=None, hop_index=0
):
    """Perform basic URL checks."""
    reputation = _reputation(url, threats)
    parsed = urlparse(url)
    hostname = parsed.hostname or ""
    is_https = parsed.scheme == "https"
    findings = []
    if not is_https:
        findings.append({
            "id": "https_not_used",
            "category": "Transport Security",
            "severity": "info",
            "evidence": "The submitted URL does not use HTTPS.",
            "limitation": (
                "This checks the submitted URL only. "
                "It does not test redirects or server configuration."
            )
        })
    if hostname:
        findings.append({
            "id": "hostname_detected",
            "category": "URL Information",
            "severity": "info",
            "evidence": f"Hostname identified: {hostname}",
        })
    threat_category = reputation["threat_category"]
    if threat_category:
        findings.append({
            "id": "threat_list_match",
            "category": "URL Reputation",
            **{key: reputation[key] for key in (
                "threat_category", "lookup_source", "lookup_time", "dataset_version", "dataset_timestamp"
            )},
            "severity": "high",
            "evidence": f"The exact URL matched the configured threat list for {threat_category}.",
        })
    port_allowed = _live_http_port_allowed(urlsplit(url))
    if threat_category:
        skip_reason = "threat_list_match"
    elif offline_reason:
        skip_reason = offline_reason
    elif not port_allowed:
        skip_reason = "unapproved_port"
    elif force_offline:
        skip_reason = "dns_failure"
    else:
        skip_reason = None
    if skip_reason and not threat_category:
        reasons = {
            "unapproved_port": "this custom port is not approved for live inspection",
            "dns_failure": "the hostname could not be resolved",
            "offline_batch": "this batch uses offline evidence",
        }
        findings.append({
            "id": "live_scan_skipped", "category": "Connection", "severity": "info",
            "evidence": f"No live HTTP request was made: {reasons[skip_reason]}.",
        })
    live_checks, header_values, failure_reason = _inspect_live_response(
        url, findings, addresses, redirect_targets=redirect_targets,
        skip_request=skip_reason is not None,
    )
    observation = _live_observation(
        url, hop_index, live_checks, header_values, skip_reason=skip_reason,
        failure_reason=failure_reason,
    )
    _attach_observations(findings, observation, live_checks)
    severities = {finding["severity"] for finding in findings}
    status_code = live_checks["http_status_code"]
    if threat_category:
        risk_level = "High"
        risk_reason = f"The URL matched the configured threat list for {threat_category}."
    elif any(f.get("id") == "tls_verification_failed" for f in findings):
        risk_level = "High"
        risk_reason = (
            "The scanner could not verify the HTTPS connection. "
            "The cause of the transport failure remains undetermined."
        )
    elif not live_checks["request_completed"]:
        risk_level = "Not enough information"
        risk_reason = "The scanner did not receive an HTTP response."
    elif "high" in severities:
        risk_level = "High"
        risk_reason = "The scan recorded a high-severity security finding."
    elif not is_https:
        risk_level = "Medium"
        risk_reason = "The URL responded over unencrypted HTTP."
    elif "medium" in severities:
        risk_level = "Medium"
        risk_reason = "The scan recorded a medium-severity security finding."
    elif status_code is None or not 200 <= status_code < 300:
        risk_level = "Not enough information"
        risk_reason = f"The page returned HTTP {status_code}."
    elif "low" in severities:
        risk_level = "Low"
        risk_reason = "The scan found only low-severity configuration issues."
    else:
        risk_level = "Low"
        risk_reason = "The surface checks found no major issues."
    return {
        "url": url,
        "checks": {
            "https_in_submitted_url": is_https,
            "hostname_present": bool(hostname),
            "live_response": live_checks,
            "live_observation": observation,
            "reputation": reputation,
        },
        "findings": findings,
        "preliminary_assessment": {
            "risk_level": risk_level,
            "reason": risk_reason,
        },
    }


def _live_observation(url, hop_index, live, header_values, *, skip_reason=None, failure_reason=None):
    """Represent the HTTP attempt separately from the legacy response checks."""
    received = live.get("request_completed", False)
    verified = live.get("tls_connection_verified")
    if skip_reason:
        state, reason = "skipped", skip_reason
    elif received:
        state, reason = "response_received", None
    else:
        state, reason = "failed", failure_reason

    if skip_reason:
        tls_status = "not_checked"
    elif urlsplit(url).scheme != "https":
        tls_status = "not_applicable"
    elif verified is True:
        tls_status = "verified"
    elif verified is False:
        tls_status = "failed"
    else:
        tls_status = "unknown"

    response_url = None
    if received:
        parsed = urlsplit(_normalise_http_url(url, enforce_port_policy=False))
        response_url = f"{parsed.scheme}://{parsed.netloc}{_request_path(parsed)}"
    legacy_headers = live.get("security_headers", {})
    return {
        "url": url,
        "response_url": response_url,
        "hop_index": hop_index,
        "response_ref": f"hop-{hop_index}" if received else None,
        "state": state,
        "reason_code": reason,
        "http_status_code": live.get("http_status_code"),
        "tls_status": tls_status,
        "tls_connection_verified": verified,
        "security_headers": {
            key: {
                "headers_present": {name: bool(header_values[name]) if name in header_values else None for name in names},
                "values": {name: header_values.get(name) for name in names},
                "passes_check": legacy_headers.get(key),
            }
            for key, names in HEADER_CHECKS.items()
        },
        "cookies_detected": live.get("cookies_detected") if received else None,
        "cookies": live.get("cookies") if received else None,
        "server_header_present": live.get("server_header_present") if received else None,
    }


def _attach_observations(findings, observation, live):
    """Add machine-readable provenance without changing any existing finding IDs."""
    for finding in findings:
        finding_id = finding["id"]
        context = {"url": observation["url"], "hop_index": observation["hop_index"]}
        if observation["response_ref"] is not None:
            context.update(response_ref=observation["response_ref"], response_url=observation["response_url"],
                           http_status_code=observation["http_status_code"], tls_status=observation["tls_status"],
                           tls_connection_verified=observation["tls_connection_verified"])
        if finding_id in ("hostname_detected", "https_not_used"):
            context["source"] = "url"
        elif finding_id == "threat_list_match":
            context.update(source="threat_list", reason_code=observation["reason_code"])
        elif finding_id == "live_scan_skipped":
            context.update(source="request_policy", reason_code=observation["reason_code"])
        elif finding_id in ("tls_verification_failed", "request_timeout", "connection_error"):
            context.update(
                source="request_attempt", reason_code=observation["reason_code"],
                http_status_code=None, tls_status=observation["tls_status"],
                tls_connection_verified=observation["tls_connection_verified"],
            )
        else:
            context["source"] = "http_response"
            if finding_id in HEADER_FINDINGS:
                context["header_evidence"] = observation["security_headers"][HEADER_FINDINGS[finding_id]]
            if finding_id in ("redirect_detected", "https_redirects_to_http"):
                context["header_evidence"] = {
                    "headers_present": {"Location": True},
                    "target_scheme": live["redirect_target_scheme"],
                }
        finding.setdefault("observation_context", {}).update(context)


def _get_set_cookie_headers(response):
    """Get individual Set-Cookie headers from the response."""
    return response.headers.get_all("Set-Cookie", [])


def _parse_csp_directives(csp_value):
    """Extract basic Content-Security-Policy directives."""
    directives = {}
    for directive in csp_value.split(";"):
        parts = directive.strip().lower().split()
        if parts:
            directives[parts[0]] = parts[1:]
    return directives


def _inspect_live_response(
    url, findings, addresses=None, *, redirect_targets=None, skip_request=False
):
    """Perform checks on the website's HTTP response."""
    parsed = urlparse(url)
    live_checks = {
        "request_completed": False,
        "http_status_code": None,
        "tls_connection_verified": None,
        "security_headers": {},
        "cookies_detected": False,
        "cookies": [],
        "redirect_detected": False,
        "server_header_present": False
    }
    header_values = {}
    failure_reason = None
    if skip_request:
        return live_checks, header_values, failure_reason
    try:
        with _open_public_response(url, addresses) as response:
            live_checks["request_completed"] = True
            live_checks["http_status_code"] = response.status
            live_checks["server_header_present"] = "Server" in response.headers
            if parsed.scheme == "https":
                live_checks["tls_connection_verified"] = True
            header_values = {
                name: response.headers.get_all(name, [])
                for names in HEADER_CHECKS.values()
                for name in names
            }
            assess_page_headers = 200 <= response.status < 300
            # 1. Check Content-Security-Policy, X-Content-Type-Options
            csp_value = response.headers.get(
                "Content-Security-Policy", ""
            )
            csp_directives = _parse_csp_directives(csp_value)
            csp_present = bool(csp_value.strip())
            live_checks["security_headers"][
                "content_security_policy"
            ] = csp_present
            if assess_page_headers and not csp_present:
                findings.append({
                    "id": "missing_csp",
                    "category": "HTTP Security",
                    "severity": "low",
                    "evidence": (
                        "Content-Security-Policy header "
                        "was not detected."
                    ),
                    "limitation": (
                        "A missing CSP header does not prove "
                        "that the website is vulnerable."
                    )
                })
            # 2. X-Content-Type-Options
            xcto_value = response.headers.get(
                "X-Content-Type-Options", ""
            ).strip().lower()
            xcto_configured = xcto_value == "nosniff"
            live_checks["security_headers"][
                "x_content_type_options"
            ] = xcto_configured
            if assess_page_headers and not xcto_configured:
                findings.append({
                    "id": "weak_x_content_type_options",
                    "category": "HTTP Security",
                    "severity": "low",
                    "evidence": (
                        "X-Content-Type-Options is missing "
                        "or is not configured as 'nosniff'."
                    )
                })
            # 3. Strict-Transport-Security (HTTPS only)
            if parsed.scheme.lower() == "https":
                hsts_value = response.headers.get(
                    "Strict-Transport-Security", ""
                )
                max_age = re.search(
                    r"(?:^|;)\s*max-age\s*=\s*([0-9]+)\s*(?:;|$)",
                    hsts_value,
                    re.IGNORECASE
                )
                hsts_configured = bool(
                    max_age and max_age.group(1).lstrip("0")
                )
                live_checks["security_headers"][
                    "strict_transport_security"
                ] = hsts_configured
                if assess_page_headers and not hsts_configured:
                    findings.append({
                        "id": "missing_or_weak_hsts",
                        "category": "Transport Security",
                        "severity": "low",
                        "evidence": (
                            "HSTS is missing or does not specify "
                            "a positive max-age value."
                        )
                    })
            else:
                live_checks["security_headers"][
                    "strict_transport_security"
                ] = None
            # 4. Clickjacking protection
            xfo_value = response.headers.get(
                "X-Frame-Options", ""
            ).strip().lower()
            xfo_protection = xfo_value in (
                "deny",
                "sameorigin"
            )
            frame_ancestors = csp_directives.get(
                "frame-ancestors", []
            )
            csp_frame_protection = (
                bool(frame_ancestors)
                and frame_ancestors != ["*"]
            )
            frame_protection = (
                xfo_protection or csp_frame_protection
            )
            live_checks["security_headers"][
                "frame_protection"
            ] = frame_protection
            if assess_page_headers and not frame_protection:
                findings.append({
                    "id": "missing_frame_protection",
                    "category": "HTTP Security",
                    "severity": "low",
                    "evidence": (
                        "Neither a recognised X-Frame-Options "
                        "value nor a restrictive CSP "
                        "frame-ancestors directive was detected."
                    )
                })
            # 5. Cookie security attributes
            cookie_headers = _get_set_cookie_headers(response)
            live_checks["cookies_detected"] = bool(cookie_headers)
            for raw_cookie in cookie_headers:
                cookie = SimpleCookie()
                try:
                    cookie.load(raw_cookie)
                except CookieError:
                    continue
                for cookie_name, morsel in cookie.items():
                    secure = bool(morsel["secure"])
                    httponly = bool(morsel["httponly"])
                    samesite = morsel["samesite"].strip().lower()
                    # Store attributes, never the cookie value.
                    cookie_evidence = {
                        "name": cookie_name,
                        "index": len(live_checks["cookies"]),
                        "max_age": morsel["max-age"] or None,
                        "expires": morsel["expires"] or None,
                        "domain": morsel["domain"] or None,
                        "path": morsel["path"] or None,
                        "secure": secure,
                        "httponly": httponly,
                        "samesite": samesite or None
                    }
                    live_checks["cookies"].append(cookie_evidence)
                    start_index = len(findings)
                    if not secure:
                        findings.append({
                            "id": "cookie_missing_secure",
                            "category": "Cookie Security",
                            "severity": "low",
                            "evidence": (
                                f"Cookie '{cookie_name}' "
                                "does not include the Secure attribute."
                            ),
                            "limitation": (
                                "The scanner cannot determine whether "
                                "this cookie contains sensitive data."
                            )
                        })
                    if not httponly:
                        findings.append({
                            "id": "cookie_missing_httponly",
                            "category": "Cookie Security",
                            "severity": "low",
                            "evidence": (
                                f"Cookie '{cookie_name}' "
                                "does not include the HttpOnly attribute."
                            ),
                            "limitation": (
                                "Not every cookie needs HttpOnly. "
                                "The scanner cannot determine its purpose."
                            )
                        })
                    if not samesite:
                        findings.append({
                            "id": "cookie_missing_samesite",
                            "category": "Cookie Security",
                            "severity": "low",
                            "evidence": (
                                f"Cookie '{cookie_name}' "
                                "does not specify a SameSite attribute."
                            )
                        })
                    elif samesite not in (
                        "strict",
                        "lax",
                        "none"
                    ):
                        findings.append({
                            "id": "cookie_invalid_samesite",
                            "category": "Cookie Security",
                            "severity": "low",
                            "evidence": (
                                f"Cookie '{cookie_name}' has an "
                                "unrecognised SameSite value."
                            )
                        })
                    if samesite == "none" and not secure:
                        findings.append({
                            "id": "cookie_samesite_none_without_secure",
                            "category": "Cookie Security",
                            "severity": "low",
                            "evidence": (
                                f"Cookie '{cookie_name}' uses "
                                "SameSite=None without Secure."
                            )
                        })
                    for finding in findings[start_index:]:
                        finding["observation_context"] = {"cookie_evidence": cookie_evidence}
            # 6. Record the Location for the separate validated redirect check.
            if response.status in REDIRECT_STATUSES and redirect_targets is not None:
                location = response.headers.get("Location")
                if location:
                    redirect_targets.append(location)
            if (
                response.status in (301, 302, 303, 307, 308)
                and response.headers.get("Location")
            ):
                live_checks["redirect_detected"] = True
                live_checks["redirect_status_code"] = (
                    response.status
                )
                try:
                    redirect_url = urljoin(url, response.headers["Location"])
                    target_scheme = urlparse(redirect_url).scheme.lower()
                except ValueError:
                    target_scheme = None
                live_checks["redirect_target_scheme"] = target_scheme
                findings.append({
                    "id": "redirect_detected",
                    "category": "URL Behaviour",
                    "severity": "info",
                    "evidence": (
                        "The server returned a redirect. Redirect-chain results "
                        "are recorded separately in checks.redirect_assessment."
                    )
                })
                if (
                    parsed.scheme.lower() == "https"
                    and target_scheme == "http"
                ):
                    findings.append({
                        "id": "https_redirects_to_http",
                        "category": "Transport Security",
                        "severity": "medium",
                        "evidence": (
                            "The HTTPS website redirects to an "
                            "HTTP destination without encryption."
                        )
                    })
    except ssl.SSLCertVerificationError as exc:
        evidence = "Python could not verify the server certificate."
        logger.warning("HTTPS check failed for %s: %s", parsed.hostname, exc)
        live_checks["tls_connection_verified"] = False
        failure_reason = "tls_verification_failed"
        findings.append({
            "id": "tls_verification_failed",
            "category": "Transport Security",
            "severity": "high",
            "evidence": evidence,
            "limitation": (
                "The cause may be the server, network, or scanner trust settings. "
                "Website reputation requires separate evidence."
            ),
        })
    except ssl.SSLError:
        failure_reason = "tls_handshake_error"
        findings.append({
            "id": "connection_error", "category": "Connection", "severity": "info",
            "evidence": "The TLS connection failed without a certificate verification result.",
        })
    except TimeoutError:
        failure_reason = "request_timeout"
        findings.append({
            "id": "request_timeout",
            "category": "Connection",
            "severity": "info",
            "evidence": (
                "The website did not respond within the "
                "scanner's configured timeout."
            )
        })
    except (OSError, HTTPException, ValueError, UnsafeTargetError) as exc:
        failure_reason = "dns_failure" if isinstance(exc, DomainLookupError) else "connection_error"
        findings.append({
            "id": "connection_error",
            "category": "Connection",
            "severity": "info",
            "evidence": (
                "The scanner could not complete the HTTP request."
            )
        })
    return live_checks, header_values, failure_reason
