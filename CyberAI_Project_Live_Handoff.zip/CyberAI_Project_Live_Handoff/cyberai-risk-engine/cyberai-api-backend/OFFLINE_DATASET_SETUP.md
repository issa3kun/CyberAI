# CyberAI URLhaus dataset integration

The bundled `clean_urls.csv` includes original URL labels. **No malicious URLs are opened just for reputation checks.**

Start Flask with `python app.py` (using your VS Code Python interpreter). The backend automatically reads `clean_urls.csv` located beside `app.py`. You can override the location with `CYBERAI_URL_DATASET_FILE`.

- Exact `malware` URL match: adds `threat_list_match` (High); skips live request, even if the URL points at a dead server.
- Unmatched URL on HTTP/HTTPS standard ports: original header, TLS, cookie and redirect inspection, with public-address checks.
- Unmatched URL on other ports: offline assessment only; `live_scan_skipped` explains why; risk stays `Not enough information` without other evidence.
- Unresolvable hostname: offline assessment only; private, loopback and otherwise blocked destinations are rejected.
- Custom ports that you own or are authorized to test may still be opted into live inspection using `CYBERAI_ALLOWED_HTTP_PORTS`.

The dataset's malicious labels represent historical feed indicators; matching does not mean the server remains active or malicious today. A CSV row labelled benign does not prove current safety. An unmatched URL is **not** proven benign. The `success` flag on the default `/api/scan` response means the URL passed validation, not that a live request succeeded. With `?details=1`, live availability is reported separately.

The scanner records the file name, SHA-256 version and local modification time. Match findings also carry the threat category and UTC lookup time. See [the RAE 0.4.0 guide](RAE_040_INTEGRATION.md) for offline Postman fixtures, strict batch loading and the meanings of unavailable and partial datasets.
