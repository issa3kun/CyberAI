"""Run with: python -m unittest discover -s tests -v."""
import os
import unittest
from unittest.mock import patch
from app import app

FAKE_DOMAIN = {"status": "public_address", "message": "OK", "addresses": ["93.184.215.14"]}
FAKE_SCAN = {
    "url": "https://example.com/",
    "checks": {
        "hostname_present": True, "https_in_submitted_url": True,
        "live_response": {"request_completed": True, "http_status_code": 200,
                          "tls_connection_verified": True, "security_headers": {},
                          "cookies_detected": False, "cookies": [], "redirect_detected": False,
                          "server_header_present": False},
    },
    "findings": [],
    "preliminary_assessment": {"risk_level": "Low", "reason": "Fixture"},
}
FAKE_MODEL = {"status": "available", "model_version": "adaboost-uci999-pilot",
              "prediction": "phishing", "phishing_model_score": .88,
              "top_factors": [], "explanation_status": "available"}

class ModelIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_additive_model_preserves_scanner_risk_and_ids(self):
        with patch.dict(os.environ, {"CYBERAI_N8N_SCAN_WEBHOOK_URL": ""}), \
             patch("app.inspect_domain", return_value=FAKE_DOMAIN), \
             patch("app.inspect_url", return_value=FAKE_SCAN), \
             patch("app.predict_ml_url", return_value=FAKE_MODEL):
            response = self.client.post("/api/scan", json={"url": "https://example.com/"})
        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertTrue(body["scan_id"].startswith("scan_"))
        self.assertEqual(body["url_model"]["prediction"], "phishing")
        self.assertEqual(body["preliminary_assessment"]["risk_level"], "Low")
        for field in ("checks", "findings", "preliminary_assessment", "scan_id", "url_model"):
            self.assertIn(field, body)

    def test_model_is_forwarded_with_original_scan_id(self):
        with patch.dict(os.environ, {"CYBERAI_N8N_SCAN_WEBHOOK_URL": "http://localhost:5678/webhook/cyberai-scanner-intake"}), \
             patch("app.inspect_domain", return_value=FAKE_DOMAIN), \
             patch("app.inspect_url", return_value=FAKE_SCAN), \
             patch("app.predict_ml_url", return_value=FAKE_MODEL), \
             patch("app.send_scan_result") as send:
            response = self.client.post("/api/scan", json={"url": "https://example.com/"})
        body = response.get_json()
        self.assertEqual(send.call_args.args[0]["url_model"], FAKE_MODEL)
        self.assertEqual(send.call_args.kwargs["scan_id"], body["scan_id"])
