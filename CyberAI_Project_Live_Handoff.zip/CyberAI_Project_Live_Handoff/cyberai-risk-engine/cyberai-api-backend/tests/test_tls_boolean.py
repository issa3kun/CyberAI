"""Exercise the RAE's three-valued TLS field without using the network."""
from contextlib import nullcontext
from email.message import Message
import ssl
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from scanner import url_checks as scanner


class TLSContractTests(unittest.TestCase):
    def setUp(self):
        self.enterContext(patch.object(scanner, "_load_threat_list", return_value={}))
        self.open = self.enterContext(patch.object(scanner, "_open_public_response"))

    def test_verified_https_and_plain_http(self):
        for scheme, expected in (("https", True), ("http", None)):
            with self.subTest(scheme=scheme):
                self.open.return_value = nullcontext(SimpleNamespace(status=200, headers=Message()))
                scan = scanner.inspect_url(f"{scheme}://fixture.test/")
                self.assertIs(scan["checks"]["live_response"]["tls_connection_verified"], expected)
                self.assertEqual(scan["checks"]["live_observation"]["state"], "response_received")

    def test_skipped_request(self):
        scan = scanner.inspect_url_offline("https://fixture.test/", threats={})
        self.assertIsNone(scan["checks"]["live_response"]["tls_connection_verified"])
        self.open.assert_not_called()

    def test_transport_failures(self):
        for error, reason, verified in (
            (ssl.SSLCertVerificationError("test certificate"), "tls_verification_failed", False),
            (ssl.SSLError("handshake interrupted"), "tls_handshake_error", None),
            (TimeoutError(), "request_timeout", None),
            (ConnectionRefusedError(), "connection_error", None),
        ):
            with self.subTest(reason=reason):
                self.open.side_effect = error
                scan = scanner.inspect_url("https://fixture.test/")
                obs = scan["checks"]["live_observation"]
                self.assertEqual((obs["state"], obs["reason_code"]), ("failed", reason))
                self.assertIs(obs["tls_connection_verified"], verified)
                self.assertIsNone(obs["response_url"])
                self.assertEqual("tls_verification_failed" in [f["id"] for f in scan["findings"]], verified is False)
