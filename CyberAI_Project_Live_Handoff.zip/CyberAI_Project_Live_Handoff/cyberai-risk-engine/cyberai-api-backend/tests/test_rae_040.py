"""Optional integration with the separate, unmodified RAE 0.4.0 checkout."""
from contextlib import nullcontext
from email.message import Message
import json
import os
from pathlib import Path
import ssl
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from scanner import url_checks as scanner
from scan_message import build_scan_message

RAE = os.environ.get("CYBERAI_RAE_DIR")
ROOT = Path(__file__).resolve().parents[1]
START = "https://start.example.test/"
END = "https://end.example.test/"


def reply(code, location=None):
    headers = Message()
    if location:
        headers["Location"] = location
    return nullcontext(SimpleNamespace(status=code, headers=headers))


def run_engine(code, data=None, *arguments):
    # Start in Imran's folder so imports such as scan_message refer to HIS adapter.
    proc = subprocess.run(
        [sys.executable, "-c", code, *map(str, arguments)], cwd=RAE,
        input=json.dumps(data), text=True, capture_output=True, timeout=60,
    )
    if proc.returncode:
        raise AssertionError(proc.stderr or proc.stdout)
    return json.loads(proc.stdout)


@unittest.skipUnless(RAE, "Set CYBERAI_RAE_DIR to the folder containing rae_api.py")
class RAE040Tests(unittest.TestCase):
    def test_frameworks_and_request_evidence_through_rae_route(self):
        scans = {
            "match": scanner.inspect_url_offline(START, threats={START:"malware"}),
            "batch_miss": scanner.inspect_url_offline(END, threats={}),
        }
        with patch.object(scanner, "_load_threat_list", return_value={}), \
             patch.object(scanner, "resolve_public_addresses", return_value=["93.184.215.14"]), \
             patch.object(scanner, "_open_public_response") as net:
            scans["port"] = scanner.inspect_url("https://start.example.test:38478/")
            scans["dns"] = scanner.inspect_url(START, force_offline=True)
            for label, url in (("http", "http://start.example.test/"), ("https", START)):
                net.return_value = reply(200)
                scans[label] = scanner.inspect_url(url)
            net.side_effect = [reply(302, END), reply(200)]
            scans["redirect"] = scanner.inspect_url(START)
            net.side_effect = [reply(302, END)]
            with patch.object(scanner, "_load_threat_list", return_value={END:"malware"}):
                scans["redirect_match"] = scanner.inspect_url(START)
            for label, error in (("timeout", TimeoutError()), ("cert", ssl.SSLCertVerificationError()),
                                 ("handshake", ssl.SSLError())):
                net.side_effect = error
                scans[label] = scanner.inspect_url(START)

        cases = []
        for name, scan in scans.items():
            scan["scan_id"] = "scan_" + name
            scan["url_model"] = {"status": "unavailable"}
            for framework in ("csa", "owasp"):
                cases.append([name, framework, build_scan_message(scan, framework=framework)])
        results = run_engine("""
import sys, json
from rae_api import create_app
client = create_app("local-test-token").test_client()
out = []
for name, framework, msg in json.load(sys.stdin):
    r = client.post("/api/rae/assess", json=msg, headers={"X-CyberAI-Token":"local-test-token"})
    assert r.status_code == 200, r.get_data(as_text=True)
    out.append([name, framework, r.get_json()])
print(json.dumps(out))
""", cases)
        for name, framework, body in results:
            with self.subTest(case=name, framework=framework):
                a = body["assessment"]
                self.assertEqual(a["engine_version"], "0.4.0")
                self.assertEqual(body["scan_id"], "scan_" + name)
                self.assertEqual(body["report_preferences"]["framework"], framework)
                self.assertEqual([v for v in a["validation_issues"] if v["severity"] == "error"], [])
                if name in ("port", "match", "batch_miss", "dns"):
                    self.assertEqual(a["scan"]["status"], "offline_only")
                if name == "match":
                    match = next(f for f in a["findings"] if f["id"] == "threat_list_match")
                    self.assertEqual((match["validation_status"], match["threat_category"]), ("reputation_match", "malware"))
                if name == "http":
                    f = next(f for f in a["findings"] if f["id"] == "https_not_used")
                    self.assertTrue(f["scoring_evidence"]["rule_id"])
                if name in ("cert","timeout","handshake"):
                    self.assertEqual(a["scan"]["status"], "failed")
                if name == "redirect":
                    self.assertTrue(a["scan"]["destination_assessed"])
                if name == "redirect_match":
                    self.assertEqual(a["scan"]["redirect_assessment"]["status"], "threat_list_match")

    def test_both_batch_scripts_use_this_scanner(self):
        with tempfile.TemporaryDirectory() as folder:
            counts = run_engine("""
import sys, json
from pathlib import Path
from unittest.mock import patch
root, tmp = map(Path, sys.argv[1:])
# Load this scanner before the scripts prepend their own backend directory.
sys.path.insert(0, str(root))
from scanner import url_checks
sys.path.pop(0)
import rae_batch, rae_bryan_batch
assert rae_batch.inspect_url_offline is url_checks.inspect_url_offline
assert rae_bryan_batch.load_csv_threats is url_checks.load_csv_threats
csvfile = tmp / "list.csv"
csvfile.write_text("url,label\\nhttps://one.example.test/,malware\\n", encoding="utf-8")
export = tmp / "export.csv"
export.write_text("id,url,url_status,threat\\n1,https://one.example.test/,online,malware\\n2,https://two.example.test/,online,malware\\n",encoding="utf-8")
with patch("socket.getaddrinfo", side_effect=AssertionError("DNS in offline mode")), patch("socket.socket.connect", side_effect=AssertionError("network in offline mode")):
    summaries = [runner.run_batch(export,csvfile,tmp/str(i)) for i,runner in enumerate((rae_batch,rae_bryan_batch))]
print(json.dumps([s["scanner_lookup_counts"] for s in summaries]))
""", None, ROOT, folder)
        self.assertEqual(counts, [{"match": 1, "no_match": 1}] * 2)
