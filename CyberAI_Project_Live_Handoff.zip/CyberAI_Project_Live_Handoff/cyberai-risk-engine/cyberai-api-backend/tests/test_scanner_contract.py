"""Request evidence, batch, model fallback and n8n contract regressions."""
from contextlib import nullcontext
from email.message import Message
import csv
import importlib.util
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from app import app
from n8n_client import DeliveryError
from scanner import url_checks as scanner
from scan_message import build_scan_message
from send_scan import main as send_cli
from url_model import predict_url

URL = "https://first.example.test/"
MIDDLE = "https://middle.example.test/"
FINAL = "https://final.example.test/"


def response(code, fields=()):
    headers = Message()
    for name, value in fields:
        headers[name] = value
    return nullcontext(SimpleNamespace(status=code, headers=headers))


def finding(scan, ident):
    return next(f for f in scan["findings"] if f["id"] == ident)


class ScannerContractTests(unittest.TestCase):
    def setUp(self):
        self.folder = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.env = self.enterContext(patch.dict(os.environ, {"CYBERAI_ALLOWED_HTTP_PORTS": ""}))
        self.open = self.enterContext(patch.object(scanner, "_open_public_response"))
        self.dns = self.enterContext(patch.object(scanner, "resolve_public_addresses", return_value=["93.184.215.14"]))

    def test_offline_supplied_data_and_dataset_errors(self):
        path = self.folder / "indicators.csv"
        path.write_text(f"url,label\n{URL},malware\n", encoding="utf-8")
        index = scanner.load_csv_threats(path, strict=True)
        with patch.object(scanner, "_load_threat_list", side_effect=AssertionError("batch used global data")):
            matched = scanner.inspect_url_offline(URL, threats=index)
            miss = scanner.inspect_url_offline(FINAL, threats=index)
            with self.assertRaises(ValueError):
                scanner.inspect_url_offline("https://example.test:no/", threats=index)
        self.open.assert_not_called()
        self.dns.assert_not_called()
        f = finding(matched, "threat_list_match")
        self.assertEqual((f["threat_category"], f["lookup_source"]), ("malware", path.name))
        self.assertRegex(f["dataset_version"], r"^sha256:[a-f0-9]{64}$")
        self.assertTrue(f["lookup_time"] and f["dataset_timestamp"])
        self.assertEqual(matched["checks"]["live_observation"]["reason_code"], "threat_list_match")
        self.assertEqual(miss["checks"]["reputation"]["status"], "no_match")
        self.assertEqual(miss["checks"]["live_observation"]["reason_code"], "offline_batch")
        self.assertIsNone(miss["checks"]["live_observation"]["security_headers"]["content_security_policy"]["values"]["Content-Security-Policy"])
        missing = self.folder / "missing.csv"
        with self.assertRaisesRegex(OSError, "missing.csv"):
            scanner.load_csv_threats(missing, strict=True)
        unavailable = scanner.inspect_url_offline(URL, threats=scanner.load_csv_threats(missing))
        self.assertEqual(unavailable["checks"]["reputation"]["status"], "unavailable")
        for invalid in ("name,value\na,b", "url,label\nbad,malware", 'url,label\n"unterminated,malware'):
            path.write_text(invalid, encoding="utf-8")
            with self.assertRaisesRegex((csv.Error, ValueError), "indicators.csv"):
                scanner.load_csv_threats(path, strict=True)

    def test_reputation_source_precedence_and_refresh(self):
        csv_path = self.folder / "one.csv"
        config = self.folder / "two.json"
        csv_path.write_text(f"url,label\n{URL},malware\n", encoding="utf-8")
        config.write_text(json.dumps({URL: "phishing"}), encoding="utf-8")
        with patch.dict(os.environ, {"CYBERAI_URL_DATASET_FILE": str(csv_path), "CYBERAI_THREAT_LIST_FILE": str(config)}):
            f = finding(scanner.inspect_url(URL), "threat_list_match")
            self.assertEqual((f["threat_category"], f["lookup_source"]), ("phishing", config.name))
            config.unlink()
            partial = scanner.inspect_url(FINAL, force_offline=True)["checks"]["reputation"]
            self.assertEqual(partial["status"], "partial")
            csv_path.write_text(f"url,label\n{FINAL},malware\n", encoding="utf-8")
            self.assertEqual(finding(scanner.inspect_url(FINAL), "threat_list_match")["lookup_source"], csv_path.name)
        self.open.assert_not_called()

    def test_redirects_and_cookie_identity(self):
        self.open.side_effect = [
            response(302, [("Location", MIDDLE)]),
            response(307, [("Location", FINAL), ("Set-Cookie", "sid=PRIVATE1; Path=/a; Domain=example.test; HttpOnly"),
                           ("Set-Cookie", "sid=PRIVATE2; Path=/b; Secure")]),
            response(200, [("X-Content-Type-Options", "wrong"), ("Strict-Transport-Security", "max-age=90")]),
        ]
        with patch.object(scanner, "_load_threat_list", return_value={}):
            scan = scanner.inspect_url(URL)
        chain = scan["checks"]["redirect_assessment"]
        self.assertEqual(chain["redirects_followed"], 2)
        self.assertEqual(chain["hops"][0]["source_response_ref"], "hop-0")
        ctx = next(f["observation_context"] for f in chain["hops"][0]["destination_findings"] if f["id"] == "cookie_missing_secure")
        self.assertEqual((ctx["response_url"], ctx["response_ref"], ctx["http_status_code"]), (MIDDLE, "hop-1", 307))
        self.assertEqual((ctx["cookie_evidence"]["index"], ctx["cookie_evidence"]["domain"], ctx["cookie_evidence"]["path"]), (0, "example.test", "/a"))
        final = chain["final_result"]
        h = finding(final, "weak_x_content_type_options")["observation_context"]
        self.assertEqual((h["response_url"], h["http_status_code"], h["tls_connection_verified"]), (FINAL, 200, True))
        self.assertEqual(h["header_evidence"]["values"]["X-Content-Type-Options"], ["wrong"])
        self.assertEqual(finding(final, "missing_csp")["observation_context"]["header_evidence"]["values"]["Content-Security-Policy"], [])
        self.assertNotIn("PRIVATE", json.dumps(scan))

    def test_redirect_to_match_and_restricted_destinations(self):
        for dest, expected in ((FINAL, "threat_list_match"), (FINAL[:-1] + ":38478/", "unapproved_port"),
                               ("http://final.example.test/", "https_downgrade")):
            self.open.reset_mock()
            self.open.return_value = response(302, [("Location", dest)])
            with patch.object(scanner, "_load_threat_list", return_value={FINAL: "malware"}):
                chain = scanner.inspect_url(URL)["checks"]["redirect_assessment"]
            self.assertEqual(chain["hops"][0]["destination_observation"]["reason_code"], expected)
            self.assertFalse(chain["hops"][0]["followed"])
            self.assertEqual(chain["redirects_followed"], 0)
            self.open.assert_called_once()

    def test_flask_handoff_and_failure(self):
        client = app.test_client()
        with patch.dict(os.environ, {"CYBERAI_N8N_SCAN_WEBHOOK_URL": "http://localhost/intake"}), \
             patch("app.inspect_domain", return_value={"status": "public_address", "addresses": ["93.184.215.14"]}), \
             patch.object(scanner, "_load_threat_list", return_value={}), \
             patch("app.predict_ml_url", return_value={"status": "unavailable"}), \
             patch("send_scan.post_json") as post:
            self.open.side_effect = TimeoutError()
            r = client.post("/api/scan", json={"url": "first.example.test", "framework": "owasp"})
            msg = post.call_args.args[0]
            self.assertEqual(msg["scan_result"], r.json)
            self.assertEqual(msg["scan_id"], r.json["scan_id"])
            self.assertEqual((msg["framework"], msg["contract_version"], msg["event"]),
                             ("owasp", "cyberai.scanner.intake/0.1.0-draft", "cyberai.scanner.result_ready"))
            self.assertEqual(r.json["submitted_url"], "first.example.test")
            self.assertEqual(r.json["checks"]["live_observation"]["reason_code"], "request_timeout")
            post.side_effect = DeliveryError("n8n offline")
            with self.assertLogs(app.logger, level="WARNING"):
                r = client.post("/api/scan", json={"url": "https://example.test:38478/"})
            self.assertEqual(r.status_code, 200)
            self.assertEqual(post.call_args.args[0]["framework"], "csa")
            self.assertEqual(r.json["checks"]["live_observation"]["reason_code"], "unapproved_port")
            count = post.call_count
            self.assertEqual(client.post("/api/scan", json={"url": URL,"framework":"other"}).status_code, 400)
            self.assertEqual(count, post.call_count)

    def test_flask_dns_failure_and_private_address_policy(self):
        with patch.dict(os.environ, {"CYBERAI_N8N_SCAN_WEBHOOK_URL": ""}), patch.object(scanner, "_load_threat_list", return_value={}), \
             patch("app.predict_ml_url", return_value={"status":"unavailable"}), patch("app.inspect_domain") as resolver:
            resolver.return_value = {"status":"lookup_failed", "addresses":[], "message":"dns"}
            scan = app.test_client().post("/api/scan", json={"url":URL}).json
            self.assertEqual(scan["checks"]["live_observation"]["reason_code"], "dns_failure")
            resolver.return_value = {"status":"blocked", "addresses":[], "message":"policy"}
            self.assertEqual(app.test_client().post("/api/scan", json={"url":URL}).status_code, 400)
            self.open.assert_not_called()

    def test_cli_framework_and_legacy_id(self):
        scan = scanner.inspect_url_offline(URL, threats={})
        scan["scan_id"] = "scan_fixture"
        path = self.folder / "scan.json"
        path.write_text(json.dumps(scan), encoding="utf-8")
        for options, expected in (([], "csa"), (["--framework","owasp"], "owasp")):
            with patch("send_scan.post_json", return_value={"http_status":200}) as post:
                send_cli([str(path), *options])
                self.assertEqual((post.call_args.args[0]["framework"], post.call_args.args[0]["scan_id"]), (expected, "scan_fixture"))
        with self.assertRaisesRegex(ValueError, "differs"):
            build_scan_message(scan, scan_id="wrong")
        with self.assertRaisesRegex(ValueError, "framework"):
            build_scan_message(scan, framework="other")

    def test_model_failure_retains_scope_and_custom_port_warning(self):
        with patch("url_model._load_model", side_effect=RuntimeError("fixture")):
            result = predict_url("https://example.test:38478/")
        self.assertEqual((result["status"], result["explanation_status"]), ("unavailable", "unavailable"))
        self.assertEqual(result["score_type"], "uncalibrated_phishing_model_score")
        self.assertIn("custom-port", result["warning"])


    @unittest.skipUnless(all(importlib.util.find_spec(x) for x in ("sklearn", "pandas", "tldextract")),
                         "ML dependencies are optional")
    def test_shap_failure_preserves_real_prediction(self):
        with patch.dict(os.environ, {"CYBERAI_ENABLE_SHAP":"1"}), \
             patch("url_model._make_explainer", side_effect=RuntimeError("fixture")), \
             self.assertLogs("url_model", level="WARNING"):
            model = predict_url("https://www.example.com/")
        self.assertEqual((model["status"], model["explanation_status"]), ("available", "unavailable"))
        self.assertIsInstance(model["phishing_model_score"], float)
        self.assertEqual(model["top_factors"], [])
