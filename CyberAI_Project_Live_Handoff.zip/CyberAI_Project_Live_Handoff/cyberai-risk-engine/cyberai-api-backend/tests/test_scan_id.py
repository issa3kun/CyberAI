"""Run with `python -m unittest discover -s tests -v` after installing requirements."""

import os
import re
import unittest
from unittest.mock import patch

from app import app


FAKE_DOMAIN = {"status": "public_address", "message": "OK", "addresses": ["93.184.215.14"]}
FAKE_SCAN = {
    "url": "https://example.com/",
    "checks": {
        "hostname_present": True,
        "https_in_submitted_url": True,
        "live_response": {
            "request_completed": True,
            "http_status_code": 200,
            "tls_connection_verified": True,
            "security_headers": {},
            "cookies_detected": False,
            "cookies": [],
            "redirect_detected": False,
            "server_header_present": False,
        },
    },
    "findings": [],
    "preliminary_assessment": {"risk_level": "Low", "reason": "Test fixture"},
}


class ScanIdTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def _scan(self, url="https://example.com/"):
        with patch("app.inspect_domain", return_value=FAKE_DOMAIN), \
             patch("app.inspect_url", return_value=FAKE_SCAN):
            return self.client.post("/api/scan", json={"url": url})

    def test_scan_ids_unique_and_original_contract_kept(self):
        with patch.dict(os.environ, {"CYBERAI_N8N_SCAN_WEBHOOK_URL": ""}):
            first = self._scan()
            second = self._scan()
        self.assertEqual(first.status_code, 200)
        a, b = first.get_json(), second.get_json()
        self.assertRegex(a["scan_id"], r"^scan_[0-9a-f]{32}$")
        self.assertNotEqual(a["scan_id"], b["scan_id"])
        for key in ("url", "checks", "findings", "preliminary_assessment", "success", "status", "scan_type"):
            self.assertIn(key, a)
        self.assertEqual(a["preliminary_assessment"]["risk_level"], "Low")

    def test_validation_error_has_id(self):
        response = self.client.post("/api/scan", json={"url": "not a valid URL with spaces"})
        self.assertEqual(response.status_code, 400)
        self.assertRegex(response.get_json()["scan_id"], r"^scan_[0-9a-f]{32}$")

    def test_custom_port_url_receives_scan_id(self):
        with patch.dict(os.environ, {"CYBERAI_N8N_SCAN_WEBHOOK_URL": ""}):
            response = self._scan("http://example.com:38478/i")
        self.assertEqual(response.status_code, 200)
        self.assertIn("scan_id", response.get_json())

    def test_n8n_receives_matching_scan_id(self):
        with patch.dict(os.environ, {"CYBERAI_N8N_SCAN_WEBHOOK_URL": "http://localhost:5678/webhook/cyberai-scanner-intake"}), \
             patch("app.send_scan_result") as sender:
            response = self._scan()
        scanner_id = response.get_json()["scan_id"]
        sender.assert_called_once()
        args, kwargs = sender.call_args
        self.assertEqual(args[0]["scan_id"], scanner_id)
        self.assertEqual(kwargs["scan_id"], scanner_id)


if __name__ == "__main__":
    unittest.main()
