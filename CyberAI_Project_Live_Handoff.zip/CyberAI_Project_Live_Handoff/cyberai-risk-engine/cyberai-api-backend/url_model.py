"""Offline inference from CyberAI_999's AdaBoost URL-classification pilot.

No URL is visited; all checks use only the submitted URL string. This is a
benign-vs-phishing pilot and does not diagnose arbitrary malware or vulnerabilities.
"""
from functools import lru_cache
import json
import logging
import math
import os
from pathlib import Path
from urllib.parse import urlsplit

logger = logging.getLogger(__name__)
BASE = Path(__file__).resolve().parent
MODEL_FILE = BASE / "models" / "adaboost_uci999.joblib"
BACKGROUND_FILE = BASE / "models" / "shap_background.json"


@lru_cache(maxsize=1)
def _load_model():
    # joblib is a pickle format: use ONLY trusted, locally trained model files.
    import joblib
    bundle = joblib.load(MODEL_FILE)
    from ml.url_features import FEATURES
    if bundle["features"] != FEATURES:
        raise ValueError("Model features do not match the URL feature extractor.")
    model = bundle["model"]
    if "phishing" not in model.classes_ or "benign" not in model.classes_:
        raise ValueError("Expected a benign/phishing model.")
    return model, bundle["features"]


@lru_cache(maxsize=1)
def _make_explainer():
    import pandas as pd
    import shap
    model, columns = _load_model()
    obj = json.loads(BACKGROUND_FILE.read_text(encoding="utf-8"))
    if obj["features"] != columns:
        raise ValueError("SHAP background features do not match the trained model.")
    background = pd.DataFrame(obj["rows"], columns=columns)
    phishing_index = list(model.classes_).index("phishing")

    def phishing_score(data):
        frame = pd.DataFrame(data, columns=columns)
        return model.predict_proba(frame)[:, phishing_index]

    return shap.PermutationExplainer(phishing_score, background, seed=42)


def predict_url(url):
    """Return model evidence and optional live SHAP explanation; never raise to Flask."""
    result = {
        "status": "unavailable",
        "scope": "URL text only, benign versus phishing",
        "score_type": "uncalibrated_phishing_model_score",
        "model_version": "adaboost-uci999-pilot",
        "prediction": None,
        "phishing_model_score": None,
        "shap_base_score": None,
        "top_factors": [],
        "explanation_status": "unavailable",
    }
    try:
        parsed = urlsplit(url)
        default = 443 if parsed.scheme == "https" else 80
        if parsed.port not in (None, default):
            result["warning"] = (
                "This model was trained on standard-port URLs and does not use "
                "port numbers as a feature; custom-port predictions need extra validation."
            )
        from ml.url_features import extract
        import pandas as pd
        _, _, values = extract(url)
        model, columns = _load_model()
        frame = pd.DataFrame([values], columns=columns)
        phishing_index = list(model.classes_).index("phishing")
        score = float(model.predict_proba(frame)[0, phishing_index])
        if not 0 <= score <= 1:
            raise ValueError("The classifier produced an invalid phishing class score.")
        result.update(
            status="available",
            prediction=str(model.predict(frame)[0]),
            phishing_model_score=score,
        )
    except Exception:
        logger.warning("CyberAI URL classifier unavailable", exc_info=True)
        return result

    # SHAP is an explanation of the phishing score, not an independent risk check.
    if os.environ.get("CYBERAI_ENABLE_SHAP", "1").strip().lower() in ("0", "false", "no"):
        result["explanation_status"] = "disabled"
        return result
    try:
        explainer = _make_explainer()
        explanation = explainer(frame, max_evals=2 * len(columns) + 1, silent=True)[0]
        base_score = float(explanation.base_values)
        ranked = sorted(
            ((name, float(values[name]), float(shap_value))
             for name, shap_value in zip(columns, explanation.values, strict=True)),
            key=lambda item: abs(item[2]), reverse=True,
        )
        if not math.isfinite(base_score) or any(not math.isfinite(item[2]) for item in ranked):
            raise ValueError("SHAP returned a non-finite contribution.")
        result["shap_base_score"] = base_score
        result["top_factors"] = [
            {"feature": name, "value": value, "shap_value": shap_value}
            for name, value, shap_value in ranked[:5]
        ]
        result["explanation_status"] = "available"
    except Exception:
        # A SHAP dependency error must not interrupt the security scan or model.
        logger.warning("SHAP explanation unavailable", exc_info=True)
    return result
