"""Shared offline feature extraction for training and prediction."""
import ipaddress
import re
from urllib.parse import urlsplit, urlunsplit

import tldextract

# Use the packaged Public Suffix List without a network request.
SUFFIXES = tldextract.TLDExtract(cache_dir=None, suffix_list_urls=())
HOST_LABEL = re.compile(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", re.IGNORECASE)
FEATURES = [
    "url_length", "hostname_length", "subdomain_count", "path_length",
    "query_length", "digit_count", "hostname_hyphen_count", "hostname_is_ip",
]


def extract(url):
    """Return a canonical HTTP(S) URL, its registered domain, and numeric features."""
    url = url.strip()
    if not url or len(url) > 2048 or any(
        c.isspace() or ord(c) < 32 or ord(c) == 127 for c in url
    ):
        raise ValueError("Empty, too long, or contains whitespace or a control character.")
    parsed = urlsplit(url if "://" in url else "https://" + url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Expected an HTTP(S) URL with a hostname.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Credentials in URLs are unsupported.")
    # The deployed scanner accepts valid custom ports for OFFLINE inspection.
    # This pilot was trained with standard-port URLs; ports are intentionally
    # excluded from its eight feature values to preserve training compatibility.
    if parsed.port == 0:
        raise ValueError("Port must be in the range 1-65535.")
    if not re.fullmatch(r"(?:\[[^\[\]]+\]|[^:\[\]]+)(?::[0-9]+)?", parsed.netloc):
        raise ValueError("Invalid hostname or port.")

    host = parsed.hostname.removesuffix(".")
    if not host or "%" in host:
        raise ValueError("Invalid hostname.")
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        host = host.encode("idna").decode("ascii").lower()
        if len(host) > 253 or any(not HOST_LABEL.fullmatch(part) for part in host.split(".")):
            raise ValueError("Invalid hostname.")
        split = SUFFIXES(host)
        group = split.top_domain_under_public_suffix or host
        subdomains = len(split.subdomain.split(".")) if split.subdomain else 0
        authority = host
        is_ip = 0
    else:
        group = str(ip)
        authority = f"[{group}]" if ip.version == 6 else group
        subdomains = 0
        is_ip = 1
    path = parsed.path or "/"
    model_authority = authority
    default_port = 443 if parsed.scheme == "https" else 80
    if parsed.port not in (None, default_port):
        model_authority = f"{authority}:{parsed.port}"
    canonical = urlunsplit((parsed.scheme, model_authority, path, parsed.query, ""))
    # Exclude the scheme and fragment from the feature values.
    address = authority + path + ("?" + parsed.query if parsed.query else "")
    return canonical, group, dict(zip(FEATURES, [
        len(address), len(host), subdomains, len(path), len(parsed.query),
        sum(c.isdigit() for c in address), host.count("-"), is_ip,
    ]))
