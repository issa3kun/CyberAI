"""Offline AdaBoost and SHAP model helpers."""
