"""Optional one-off test of your OpenRouter key. Does not change the Flask API.

Usage: python test_openrouter.py
The key is entered via a hidden prompt unless OPENROUTER_API_KEY is set.
"""

from getpass import getpass
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
import json
import os


def main():
    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not key:
        key = getpass("Paste your OpenRouter API key (hidden): ").strip()
    if not key:
        raise SystemExit("No API key supplied.")

    model = os.environ.get("OPENROUTER_MODEL", "qwen/qwen-2.5-7b-instruct").strip()
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are CyberAI's reporting assistant. Explain only the "
                    "given security observations in simple English. Never "
                    "invent scanner findings or change a provided rating."
                ),
            },
            {
                "role": "user",
                "content": (
                    "This is a SYNTHETIC test, not a real website scan: "
                    "risk_level=Medium, finding=https_not_used. "
                    "Explain the finding briefly to a beginner."
                ),
            },
        ],
        "temperature": 0.2,
        "max_tokens": 180,
    }
    req = Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "X-OpenRouter-Title": "CyberAI Development Test",
        },
        method="POST",
    )
    try:
        with urlopen(req, timeout=45) as resp:
            data = json.load(resp)
        print("Model:", data.get("model", model))
        print("AI explanation:")
        print(data["choices"][0]["message"]["content"])
    except HTTPError as exc:
        # Do not print request headers or the key.
        print(f"OpenRouter returned HTTP {exc.code}. Check model availability, key and credits.")
    except (URLError, TimeoutError, KeyError, IndexError, ValueError) as exc:
        print(f"OpenRouter test failed: {type(exc).__name__}. Check connectivity and model access.")


if __name__ == "__main__":
    main()
