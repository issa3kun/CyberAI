# Scanner handoff to CyberAI RAE 0.4.0

## Run on Ziyad's laptop

Extract the archive and open its inner `cyberai_api_backend` directory in VS Code. In the PowerShell terminal, check that `Test-Path .\app.py` returns `True`.

```powershell
pymanager exec -V:3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install -r requirements-ml.txt
.\.venv312\Scripts\python.exe -m unittest discover -s tests -v
.\.venv312\Scripts\python.exe test_url_model.py "https://www.example.com/"
$env:CYBERAI_N8N_SCAN_WEBHOOK_URL = "http://localhost:5678/webhook/cyberai-scanner-intake"
.\.venv312\Scripts\python.exe app.py
```

The equivalent Windows launcher command is `py -3.12 -m venv .venv312`. The first full dataset lookup indexes the local CSV. The ML smoke test uses URL text and the bundled model. For optional scanner-only installation use `requirements.txt`. The classifier reports its dependency availability.

To include Imran's real API and both batch scripts in the regression suite, set the path to the directory containing **rae_api.py** in the same terminal before running the tests. A missing environment variable skips the two external integration tests.

```powershell
$env:CYBERAI_RAE_DIR = "$env:USERPROFILE\Downloads\CyberAI_Project_Merged\cyberai-risk-engine"
Test-Path (Join-Path $env:CYBERAI_RAE_DIR 'rae_api.py')
.\.venv312\Scripts\python.exe -m unittest discover -s tests -v
```

Adjust this path if Windows created an extra outer directory. Imran's two batch scripts put their own `cyberai-risk-engine/cyberai-api-backend` first on the Python path. For routine batch runs, install the updated `scanner/url_checks.py` in that copy's `scanner` directory too. The supplied merged tree has the same `domain_checks.py`. The integration tests explicitly load this release's scanner and then run the original batch code.

## Verify the handoff

In a second PowerShell terminal, use this public IP literal and unapproved custom port as an offline fixture. Use the default port policy. On the bundled dataset this particular fixture has no exact match.

```powershell
$r = Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:5000/api/scan' -ContentType 'application/json' -Body '{"url":"https://1.1.1.1:38478/cyberai-offline-fixture","framework":"owasp"}'
$r.scan_id
$r.checks.live_observation | Select-Object state,reason_code,http_status_code,tls_connection_verified
$r.url_model | Select-Object status,explanation_status,score_type,warning
```

In Postman send the same JSON to the same URL using **Body → raw → JSON**. Expect HTTP 200, `success: true`, `skipped`, `unapproved_port`, and JSON null for HTTP status and TLS. PowerShell displays null as a blank cell. In **n8n → Executions → Receive scanner result**, compare `body.scan_id` and `body.scan_result.scan_id` with Postman. Check `body.framework` and `body.scan_result.url_model`. In the RAE node output, check `report_preferences.framework`, `assessment.engine_version` and `assessment.scan.status` for `owasp`, `0.4.0` and `offline_only`. Omit `framework` to select CSA.

The intake URL is the published production webhook. The intake and the RAE API have separate authentication settings. The supplied intake's HTTP Request node uses its configured RAE credential. Optional scanner-to-intake Header Auth uses `CYBERAI_N8N_HEADER_NAME` and `CYBERAI_N8N_HEADER_VALUE`. The scanner sends once, waits up to ten seconds for network operations, logs delivery errors with the scan ID, and returns the scan. A scanner HTTP 200 alone does not confirm n8n delivery.

For manual replay from a scanner result saved as UTF-8 JSON, run:

```powershell
.\.venv312\Scripts\python.exe send_scan.py .\scan.json --input-origin user_supplied_scan --framework owasp --timeout 10
```

Replaying sends another intake event. The sender reuses the result's ID. A conflicting explicit `--scan-id` is rejected. Older files without an ID can supply one on the CLI. The intake event is `cyberai.scanner.result_ready` and the envelope version is `cyberai.scanner.intake/0.1.0-draft`. Its `scan_result` is the complete scanner JSON. The Python sender also accepts an omitted framework for legacy callers. The RAE defaults an omitted field to CSA.

## Scanner JSON

| Field | Definition |
|---|---|
| `submitted_url` | Original URL string in a valid Flask HTTP(S) request, including any omitted scheme. `url` is the initial scanner URL after Flask preparation. |
| `checks.live_response` | Legacy initial response for RAE 0.4.0. `request_completed` indicates receipt of an HTTP response, including HTTP errors. `tls_connection_verified` is true after verified HTTPS, false for an observed certificate verification failure, null for HTTP, skipped checks and unavailable verification. |
| `checks.live_observation` | HTTP attempt for this URL. `state` is `response_received`, `skipped` or `failed`. `reason_code` is null for an observed response. The default Flask `success` still describes input validation. |
| `url`, `response_url`, `hop_index`, `response_ref` inside that observation | URL under assessment, normalized URL actually requested when a response arrived, zero-based hop, and scan-local response ID such as `hop-0`. The response URL and ID are null without a response. Use the scan ID with the hop ID across scans. |
| `http_status_code`, `tls_status` | HTTP status or null. TLS status is `verified`, `failed`, `not_applicable` for plain HTTP, `not_checked` for a skipped request, or `unknown` for an HTTPS attempt without a verification result. |
| `live_observation.security_headers.<check>` | `headers_present` records presence per header. `values` contains the observed list in response order, including repeated fields. An empty list means observed absent, null means unavailable. `passes_check` is true, false, or null when inapplicable/unavailable. Frame protection considers both CSP and X-Frame-Options. Page-header findings retain the scanner's 2xx policy. |
| `live_observation.cookies_detected`, `cookies` | Null if no response. For a response, the flag reports Set-Cookie presence and the list contains parsed cookie metadata. A present but unparsable header can yield an empty list. Cookie values are excluded. Legacy `live_response.cookies` remains a list for the RAE. |
| `findings[].observation_context` | Identifies URL, hop, and evidence source. Findings linked to a received response include its ID, URL, status and TLS result. Header findings include `header_evidence`. Cookie findings include `cookie_evidence` with index, name, domain, path, expiration attributes, Secure, HttpOnly and SameSite. Index refers to that response's parsed cookie list. An omitted cookie domain/path stays null. |
| `checks.redirect_assessment` | Top-level findings and checks describe the initial URL. Each hop links its `source_response_ref` to `to_url`. A processed destination has `destination_observation`, `destination_findings` and `destination_reputation`. Blocked valid targets record a skipped observation. `final_result` repeats the last assessed target for the RAE. Count a finding once per response. An offline match has `followed: false` and does not increment `redirects_followed`. |
| `checks.reputation` | Lookup status is `match`, `no_match`, `unavailable`, or `partial` when coverage was incomplete and no match was found. `sources[]` gives each source's availability. JSON overrides CSV for a matching key. A miss refers only to the consulted snapshot. |
| `threat_list_match` finding | `threat_category` is a legacy RAE-supported field. `lookup_source` is the local source basename, `lookup_time` is UTC at lookup, `dataset_version` is the SHA-256 of the local file, and `dataset_timestamp` is the local file modification time in UTC. The original feed publication time is unknown. Unattributed in-memory mappings use null for file identity/version/time. |
| `url_model` | Flask adds the benign-versus-phishing URL-text model's scope, status, prediction, uncalibrated `phishing_model_score`, explanation status, baseline and up to five signed SHAP factors. Positive values increase the phishing score. Custom ports carry a training-scope warning. A failed classifier or explainer leaves other evidence available. |

Common skip reasons are `threat_list_match`, `unapproved_port`, `dns_failure` and `offline_batch`. A failed HTTP attempt can report `request_timeout`, `connection_error`, `dns_failure`, `tls_handshake_error` or `tls_verification_failed`. Read state and reason together. A DNS failure before an HTTP attempt skips HTTP. Generic TLS-handshake errors use the existing `connection_error` finding and leave verification unknown. Redirect policy can also stop for `address_policy`, `https_downgrade`, `redirect_loop`, `redirect_limit`, `missing_location` or `invalid_redirect_target`.

## Compatibility and limits

Imran's 0.4.0 reads the legacy live-response fields, finding IDs, threat category, and initial/final redirect structure. The detailed observations are additive evidence for future rules. The adapter currently emits a compatibility warning for the legacy Server header flag and drops additional metadata when it constructs the report payload. The full scanner result remains in the intake. Scoring inputs and final risk belong to the RAE.

The bundled pilot used 533 training and 133 held-out URLs. It classified 87/133 correctly (65.4%) and detected 26/67 phishing URLs (38.8% recall). It missed 41 phishing URLs and flagged 5/66 benign URLs. These are benign-versus-phishing results. The URLhaus malware lookup is a separate local exact-match operation. Neither the classifier score nor SHAP is a CSA or OWASP factor rating.

Both batch entry points accept the signatures used by Imran. `inspect_url_offline(url, *, threats)` validates URL syntax and uses only the supplied local mapping. It skips HTTP, DNS, global dataset discovery and per-row ML inference, matching Imran's batch API. A dictionary from `load_csv_threats(path, strict=True)` carries its source metadata. Strict mode raises a descriptive error for an unreadable file, invalid CSV structure, invalid URL or unrecognised label. A schema-valid list of benign rows has zero indicators.

The supplied n8n scanner intake forwards the whole incoming body to the RAE and returns its assessment. Bryan's separate report workflow sends four selected header finding IDs and references to Qwen. Its export names Qwen2.5 72B Instruct; the TOR names 7B. The team still needs to confirm the deployed model, the live report handoff and validator result. The two workflows, RAE factor rules and OWASP aggregation are maintained in the merged project.
