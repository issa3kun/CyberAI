"""Offline command to validate model inference; no website is contacted."""
import json
import sys
from url_model import predict_url

if __name__ == "__main__":
    url = sys.argv[1] if len(sys.argv) > 1 else "https://www.example.com/"
    print(json.dumps(predict_url(url), indent=2))
