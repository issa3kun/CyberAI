# CyberAI: scan IDs and OpenRouter setup

## What changed

`POST /api/scan` now adds a **new top-level `scan_id`** to every JSON scan attempt (including rejected URLs). It is generated with Python `uuid4()` and looks like `scan_7c2e...` (32 lowercase hex digits after the prefix). Each new request gets a new ID, even when the URL is identical.

Existing fields (`url`, `checks`, `findings`, `preliminary_assessment`, `status`, `success`, `scan_type`, etc.) are unchanged. Neither AdaBoost nor the risk-rating logic was changed. `GET /api/health` and `POST /api/domain-check` are unchanged.

When `CYBERAI_N8N_SCAN_WEBHOOK_URL` is configured, Flask's after-request hook calls `send_scan_result(..., scan_id=scan_result["scan_id"])`. Imran's **existing** n8n envelope now has the same ID in **both** `scan_id` and `scan_result.scan_id`, making it easy to relate the results from the scanner, RAE and Bryan's workflow.

This is a *correlation ID*, not a stored job and not a retrieval API. To poll by ID, later implement a result store and an endpoint such as `GET /api/scans/<scan_id>` in the shared backend (subject to Anson's architecture).

## Setup in VS Code / PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

Test twice from Postman:

- POST `http://127.0.0.1:5000/api/scan`
- Body -> raw -> JSON: `{"url": "https://example.com/"}`
- Compare both responses' `scan_id` values: they should be different.

To run automated offline tests of IDs and the n8n call (no real network scans):

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## Your OpenRouter account

1. Create an API key in your OpenRouter dashboard at https://openrouter.ai/settings/keys. Do not paste the key into your code, the ZIP, GitHub, or chat.
2. Test your key separately (the test asks for it in a **hidden** prompt):

```powershell
.\.venv\Scripts\python.exe test_openrouter.py
```

3. The optional test uses `qwen/qwen-2.5-7b-instruct`. If your account cannot use that model, choose an available compatible Qwen model from https://openrouter.ai/models and set `OPENROUTER_MODEL` for the terminal before running the test.
4. Bryan should set up the n8n HTTP Request to `https://openrouter.ai/api/v1/chat/completions`, with Bearer Auth in **n8n credentials** and a JSON body containing `model` and `messages`. The response explanation is `choices[0].message.content`.

OpenRouter serves the AI report generation step, **not** the scanner-to-RAE link. Keep the original architecture:

`Anson frontend -> Flask scanner (scan_id) -> Imran RAE (same scan_id) -> Bryan n8n -> OpenRouter/Qwen -> report -> frontend`

To forward scanner results automatically, configure the URL of **Imran's active n8n intake** in the terminal before launching Flask:

```powershell
$env:CYBERAI_N8N_SCAN_WEBHOOK_URL = "http://localhost:5678/webhook/cyberai-scanner-intake"
.\.venv\Scripts\python.exe app.py
```

If the webhook is on a different machine, `localhost` will not reach it; ask Imran for its reachable address. Confirm a real n8n execution and check that the top-level `scan_id` equals `scan_result.scan_id`.

## Model notes and safety

`test_openrouter.py` only sends synthetic test findings, not any user-uploaded URLs or live website data. This package does **not** automatically forward all scanner JSON to OpenRouter. That remains Bryan's report-generation integration and needs privacy, model failure, and rate-limit safeguards. Be careful not to mistake `scan_id` for OpenRouter's separate request ID.
