"""CSA and OWASP calculation methods for evidence-rated scenarios."""

from fractions import Fraction

from risk_engine import calculate_likelihood, calculate_risk

CSA_LIKELIHOOD = ("discoverability", "exploitability", "reproducibility")
CSA_IMPACT = ("confidentiality", "integrity", "availability")
OWASP_LIKELIHOOD = {
    "skill_level": {1, 3, 5, 6, 9},
    "motive": {1, 4, 9},
    "opportunity": {0, 4, 7, 9},
    "size": {2, 4, 5, 6, 9},
    "ease_of_discovery": {1, 3, 7, 9},
    "ease_of_exploit": {1, 3, 5, 9},
    "awareness": {1, 4, 6, 9},
    "intrusion_detection": {1, 3, 8, 9},
}
OWASP_TECHNICAL_IMPACT = {
    "loss_of_confidentiality": {2, 6, 7, 9},
    "loss_of_integrity": {1, 3, 5, 7, 9},
    "loss_of_availability": {1, 5, 7, 9},
    "loss_of_accountability": {1, 7, 9},
}
OWASP_BUSINESS_IMPACT = {
    "financial_damage": {1, 3, 7, 9},
    "reputation_damage": {1, 4, 5, 9},
    "non_compliance": {2, 5, 7},
    "privacy_violation": {3, 5, 7, 9},
}
# Both the impact rows and likelihood columns run Low, Medium, High.
OWASP_MATRIX = (
    ("Note", "Low", "Medium"),
    ("Low", "Medium", "High"),
    ("Medium", "High", "Critical"),
)
SEVERITY_ORDER = {
    "csa": ("Low", "Medium", "Medium High", "High", "Very High"),
    "owasp": ("Note", "Low", "Medium", "High", "Critical"),
}
FRAMEWORKS = {
    "csa": {
        "name": "CSA 5×5",
        "score_max": 25,
        "source": "https://isomer-user-content.by.gov.sg/36/016e3838-a9e5-4c6e-a037-546e8b7ad684/Guide-to-Conducting-Cybersecurity-Risk-Assessment-for-CII.pdf",
    },
    "owasp": {
        "name": "OWASP Risk Rating Methodology",
        "score_max": 81,
        "score_basis": "Likelihood × impact is a CyberAI ranking number. OWASP severity comes from the bands in its matrix.",
        "source": "https://community.owasp.org/OWASP_Risk_Rating_Methodology",
    },
}


def validate_framework(framework):
    if not isinstance(framework, str) or framework not in FRAMEWORKS:
        raise ValueError("framework must be 'csa' or 'owasp'.")
    return framework


def csa_rating(likelihood_factors, impact_factors):
    return calculate_risk(calculate_likelihood(**likelihood_factors), **impact_factors)


def _mean(values, rubric):
    if set(values) != set(rubric):
        raise ValueError("OWASP scoring requires every factor in the selected rubric.")
    for name, value in values.items():
        if type(value) is not int or value not in rubric[name]:
            raise ValueError(f"Unsupported OWASP rating for {name}.")
    return Fraction(sum(values.values()), len(values))


def _band(value):
    return int(value >= 3) + int(value >= 6)


def owasp_rating(likelihood_factors, technical_impact, *, business_impact=None):
    """Apply the repeatable OWASP method and prefer supported business impact."""
    likelihood = _mean(likelihood_factors, OWASP_LIKELIHOOD)
    impact = (_mean(technical_impact, OWASP_TECHNICAL_IMPACT) if business_impact is None
              else _mean(business_impact, OWASP_BUSINESS_IMPACT))
    likelihood_band, impact_band = _band(likelihood), _band(impact)
    return {
        "likelihood": float(likelihood),
        "likelihood_level": ("Low", "Medium", "High")[likelihood_band],
        "impact": float(impact),
        "impact_level": ("Low", "Medium", "High")[impact_band],
        "impact_basis": "technical" if business_impact is None else "business",
        "risk_score": float(likelihood * impact),
        "risk_level": OWASP_MATRIX[impact_band][likelihood_band],
        "owasp_impact_factors": technical_impact if business_impact is None else business_impact,
    }


def score_supported_factors(framework, likelihood, technical_impact, *, business_impact=None):
    """Calculate a score only once a finding rule supplies the required factors."""
    validate_framework(framework)
    likelihood_keys = CSA_LIKELIHOOD if framework == "csa" else OWASP_LIKELIHOOD
    if any(likelihood.get(name) is None for name in likelihood_keys):
        return None
    if framework == "csa":
        if any(technical_impact.get(name) is None for name in CSA_IMPACT):
            return None
        return csa_rating(likelihood, technical_impact)
    if business_impact is not None and all(business_impact.get(name) is not None
                                           for name in OWASP_BUSINESS_IMPACT):
        return owasp_rating(likelihood, technical_impact, business_impact=business_impact)
    if any(technical_impact.get(name) is None for name in OWASP_TECHNICAL_IMPACT):
        return None
    return owasp_rating(likelihood, technical_impact)
