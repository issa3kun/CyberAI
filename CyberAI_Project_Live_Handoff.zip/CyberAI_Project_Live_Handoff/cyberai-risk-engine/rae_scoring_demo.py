"""Show one labelled CSA score with the CyberAI RAE and a synthetic scan."""

import argparse
import json
from pathlib import Path

from scoring_methods import score_supported_factors
from stage2_engine import _summarize, assess_scan, build_webhook_payload


DEMO_RULE_ID = "http_visitor_contact_email_demo_v1"
DEMO_SCAN = {
    "url": "http://contact-demo.invalid/contact-receipt",
    "success": True,
    "checks": {
        "hostname_present": True,
        "https_in_submitted_url": False,
        "live_response": {
            "request_completed": True,
            "http_status_code": 200,
            "redirect_detected": False,
            "tls_connection_verified": None,
            "cookies_detected": False,
            "cookies": [],
        },
    },
    "findings": [{
        "id": "https_not_used",
        "category": "Transport Security",
        "severity": "info",
        "evidence": "The synthetic response uses plain HTTP.",
    }],
}

DEMO_ASSUMPTIONS = (
    "A confirmation page returns the visitor's routine contact email in its HTTP response.",
    "The observer in this scenario has visibility of the visitor's traffic and moderate technical skill.",
    "The same disclosure can recur when the visitor repeats the confirmation and traffic is still visible.",
    "The assessed event is passive disclosure of a routine contact address.",
)

RATING_REASONS = {
    "discoverability": "3. The transport weakness is apparent when examining the observed response.",
    "exploitability": "3. The labelled demo assumes access to the traffic and moderate technical skill.",
    "reproducibility": "3. The exposure can recur under the stated confirmation and visibility conditions.",
    "confidentiality": "2. Revealing a routine contact address could cause unwanted contact and a limited loss of privacy.",
    "integrity": "1. The defined disclosure event would leave the data unchanged.",
    "availability": "1. The defined disclosure event would leave the service available.",
}


def build_demo_payload():
    """Score one visitor finding under the supplied synthetic assumptions."""
    assessment = assess_scan(DEMO_SCAN, framework="csa")
    findings = assessment["findings"]
    finding = next(item for item in findings if item["id"] == "https_not_used")
    scanner_evidence = finding["scoring_evidence"]
    likelihood = {
        **scanner_evidence["likelihood_factors"],
        "exploitability": 3,
        "reproducibility": 3,
    }
    impact = {"confidentiality": 2, "integrity": 1, "availability": 1}
    rating = score_supported_factors("csa", likelihood, impact)
    finding["perspectives"]["visitor"].update(
        **rating,
        likelihood_factors=likelihood,
        status="scored",
        rule_id=DEMO_RULE_ID,
        reason="The labelled synthetic scenario supplies all six CSA ratings for the visitor.",
        evidence={
            "scanner_observations": scanner_evidence["evidence"],
            "source": "synthetic_demo_assumptions",
            "assumptions": list(DEMO_ASSUMPTIONS),
            "rubric": "CSA CII Risk Assessment Guide, sections 4.2–4.3, Figures 3–5",
        },
        rating_reasons=RATING_REASONS.copy(),
    )
    assessment["perspectives"] = _summarize(findings, assessment["scan"]["status"], "csa")
    assessment["limitations"].insert(
        0, "Synthetic scoring demo. The contextual assumptions apply to the visitor example only."
    )
    return build_webhook_payload(
        assessment,
        input_origin="synthetic_test_data",
        literacy_level="technical",
        scan_id="demo-csa-http-visitor",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=Path("csa-scoring-demo-receipt.json"),
        help="write the complete synthetic assessment JSON to this file",
    )
    args = parser.parse_args()
    payload = build_demo_payload()
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    assessment = payload["assessment"]
    finding = next(item for item in assessment["findings"] if item["id"] == "https_not_used")
    visitor = finding["perspectives"]["visitor"]
    owner = assessment["perspectives"]["website_owner"]["overall_risk"]
    print("Synthetic demo | CSA 5x5")
    print(f"Visitor score: {visitor['risk_score']}/25 {visitor['risk_level']}")
    print(f"Visitor likelihood: {visitor['likelihood']} | Impact: {visitor['impact']}")
    print(f"Website-owner score: {'unavailable' if owner['risk_score'] is None else owner['risk_score']}")
    print(f"Full assessment and rating reasons: {args.output}")


if __name__ == "__main__":
    main()
