"""Replay URLhaus records through the CyberAI scanner and RAE offline."""

import argparse
from collections import Counter
from contextlib import contextmanager
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import BadZipFile, ZipFile

from stage2_engine import ENGINE_VERSION, assess_scan, build_webhook_payload

PROJECT_DIR = Path(__file__).resolve().parent
BACKEND_DIR = PROJECT_DIR / "cyberai-api-backend"
sys.path.insert(0, str(BACKEND_DIR))
from scanner.url_checks import inspect_url_offline, load_csv_threats

URLHAUS_COLUMNS = {"id", "url", "url_status", "threat"}


@contextmanager
def open_export(path):
    if path.suffix.lower() != ".zip":
        with path.open(encoding="utf-8-sig", newline="") as source:
            yield source
        return

    with ZipFile(path) as archive:
        members = [item for item in archive.infolist() if not item.is_dir()
                   and Path(item.filename).suffix.lower() in {".csv", ".txt"}]
        if len(members) != 1:
            raise ValueError("The URLhaus ZIP must contain one CSV or TXT export.")
        with archive.open(members[0]) as raw, io.TextIOWrapper(
                raw, encoding="utf-8-sig", newline="") as source:
            yield source


def urlhaus_rows(source):
    updated = None
    for line in source:
        line = line.strip()
        if line.startswith("#"):
            line = line.lstrip("# ").rstrip("# ")
            if line.startswith("Last updated:"):
                updated = line.partition(":")[2].strip()
            if not line.startswith("id,"):
                continue
        if not line:
            continue
        header = next(csv.reader([line], strict=True))
        if "url_defanged" in header:
            raise ValueError("Use the original URLhaus export with its url column.")
        if not URLHAUS_COLUMNS.issubset(header):
            raise ValueError("Expected a URLhaus export with id, url, url_status, and threat columns.")
        return updated, csv.DictReader(source, fieldnames=header, strict=True)
    raise ValueError("No URLhaus header found.")


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_record(stream, record):
    stream.write(json.dumps(record, ensure_ascii=True, allow_nan=False, separators=(",", ":")) + "\n")


def run_batch(export_path, threat_path, output_dir):
    threats = load_csv_threats(str(threat_path.resolve()), strict=True)
    if not threats:
        raise ValueError("The scanner threat CSV contains no usable threat URLs.")
    source_statuses = Counter()
    source_threats = Counter()
    lookup_results = Counter()
    scan_statuses = Counter()
    rejected = 0
    csa_findings_scored = 0
    csa_overall_scored = Counter({"visitor": 0, "website_owner": 0})

    output_dir = output_dir.resolve()
    if output_dir.exists():
        raise FileExistsError(f"Output folder already exists: {output_dir}")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=output_dir.parent) as staging:
        folder = Path(staging) / "results"
        folder.mkdir()
        with open_export(export_path) as source, (
                folder / "rae_results.jsonl").open("w", encoding="utf-8", newline="\n") as results, (
                folder / "rejected_rows.jsonl").open("w", encoding="utf-8", newline="\n") as rejects:
            export_updated, rows = urlhaus_rows(source)
            for row_number, row in enumerate(rows, 1):
                url_status = (row.get("url_status") or "").strip().lower()
                source_statuses[url_status or "missing"] += 1
                if url_status != "online":
                    continue
                record_id = row.get("id") or ""
                try:
                    if None in row or not record_id.isascii() or not record_id.isdecimal() or not row.get("threat"):
                        raise ValueError("The record has an invalid ID, missing threat label, or extra columns.")
                    scanner_result = inspect_url_offline(row.get("url"), threats=threats)
                except ValueError as exc:
                    rejected += 1
                    write_record(rejects, {"data_row": row_number, "reason": str(exc)})
                    continue

                assessment = assess_scan(scanner_result)
                envelope = build_webhook_payload(
                    assessment, input_origin="user_supplied_scan", scan_id=f"urlhaus-{record_id}",
                )
                matched = any(f["validation_status"] == "reputation_match" for f in assessment["findings"])
                lookup_results["match" if matched else "no_match"] += 1
                source_threats[row["threat"]] += 1
                scan_statuses[assessment["scan"]["status"]] += 1
                for perspective, data in assessment["perspectives"].items():
                    csa_findings_scored += data["findings_scored"]
                    csa_overall_scored[perspective] += data["overall_risk"]["risk_score"] is not None
                write_record(results, {
                    "collection_method": "offline_reputation_replay",
                    "urlhaus_record": row,
                    "scanner_result": scanner_result,
                    "rae_payload": envelope,
                })

        summary = {
            "collection_method": "offline_reputation_replay",
            "rae_engine_version": ENGINE_VERSION,
            "input_export": {"file": export_path.name, "updated": export_updated,
                             "sha256": sha256_file(export_path)},
            "scanner_threat_list": {"file": threat_path.name, "sha256": sha256_file(threat_path),
                                    "indexed_urls": len(threats)},
            "input_rows": sum(source_statuses.values()),
            "input_status_counts": dict(source_statuses),
            "rows_skipped_by_status": sum(source_statuses.values()) - source_statuses["online"],
            "rows_rejected": rejected,
            "rows_assessed": sum(scan_statuses.values()),
            "urlhaus_threat_counts": dict(source_threats),
            "scanner_lookup_counts": dict(lookup_results),
            "rae_scan_status_counts": dict(scan_statuses),
            "csa_perspective_finding_scores_assigned": csa_findings_scored,
            "csa_overall_scores_assigned": dict(csa_overall_scored),
        }
        (folder / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        if output_dir.exists():
            raise FileExistsError(f"Output folder already exists: {output_dir}")
        folder.rename(output_dir)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("urlhaus_export", type=Path, help="Original URLhaus ZIP, CSV, or TXT export")
    parser.add_argument("--threat-list", type=Path, default=BACKEND_DIR / "clean_urls.csv",
                        help="Scanner's URL and label CSV")
    parser.add_argument("--output", type=Path, required=True, help="New output directory")
    args = parser.parse_args(argv)
    try:
        summary = run_batch(args.urlhaus_export, args.threat_list, args.output)
    except (BadZipFile, csv.Error, OSError, ValueError) as exc:
        parser.exit(2, f"Batch failed: {exc}\n")
    counts = summary["scanner_lookup_counts"]
    print(f"Assessed {summary['rows_assessed']:,} rows. "
          f"Lookup matches: {counts.get('match', 0):,}. "
          f"No match: {counts.get('no_match', 0):,}.")
    print(f"Results saved to {args.output}")


if __name__ == "__main__":
    main()
